import fs from 'fs';
import https from 'https';
import http from 'http';
import path from 'path';
import { URL } from 'url';

const targetUrl = 'https://github.com/anthonycr/Lightning-Browser/releases/download/v4.4.1/lightningPlus-release.apk';
const dest = path.join(process.cwd(), 'public', 'jabar_drivers.apk');

function downloadFile(fileUrl, writeStream, redirectCount = 0) {
  if (redirectCount > 10) {
    console.error('Too many redirects!');
    return;
  }

  const parsedUrl = new URL(fileUrl);
  const client = parsedUrl.protocol === 'https:' ? https : http;

  const requestOptions = {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'application/octet-stream, */*'
    }
  };

  client.get(fileUrl, requestOptions, (response) => {
    const { statusCode, headers } = response;

    console.log(`[HTTP ${statusCode}] Fetching: ${fileUrl}`);

    if (statusCode >= 300 && statusCode < 400 && headers.location) {
      // Resolve relative redirect location
      const redirectUrl = new URL(headers.location, fileUrl).toString();
      console.log(`Redirecting to: ${redirectUrl}`);
      downloadFile(redirectUrl, writeStream, redirectCount + 1);
    } else if (statusCode === 200) {
      response.pipe(writeStream);
      writeStream.on('finish', () => {
        writeStream.close();
        console.log('Download completed successfully. Checking file validity...');
        
        // Double check header
        const buffer = Buffer.alloc(4);
        const fd = fs.openSync(dest, 'r');
        fs.readSync(fd, buffer, 0, 4, 0);
        fs.closeSync(fd);
        
        console.log('File size:', fs.statSync(dest).size, 'bytes');
        console.log('Magic bytes (hex):', buffer.toString('hex'));
        if (buffer.toString('hex') === '504b0304') {
          console.log('✅ VALID ZIP/APK HEADER FOUND (PK...)');
        } else {
          console.error('❌ INVALID HEADER. This is not a valid APK!');
        }
      });
    } else {
      console.error(`Status code failed: ${statusCode}`);
    }
  }).on('error', (err) => {
    console.error(`Network error: ${err.message}`);
  });
}

console.log(`Starting recursive download to ${dest}...`);
const fileStream = fs.createWriteStream(dest);
downloadFile(targetUrl, fileStream);
