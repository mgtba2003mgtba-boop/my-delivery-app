import https from 'https';

function checkRepo(repo) {
  const options = {
    hostname: 'api.github.com',
    path: `/repos/${repo}/releases`,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    }
  };

  https.get(options, (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
      try {
        const releases = JSON.parse(body);
        if (Array.isArray(releases)) {
          console.log(`Releases for ${repo}:`);
          for (const rel of releases) {
            console.log(`Release Tag: ${rel.tag_name}`);
            for (const asset of rel.assets) {
              console.log(` - Asset name: ${asset.name}`);
              console.log(`   URL: ${asset.browser_download_url}`);
            }
          }
        } else {
          console.error(`Error for ${repo}:`, releases.message || releases);
        }
      } catch (e) {
        console.error('Error parsing JSON:', e.message);
      }
    });
  }).on('error', err => {
    console.error('Network error:', err.message);
  });
}

checkRepo('mgks/Android-WebView-App');
checkRepo('onurceyhan/webview-apk');
