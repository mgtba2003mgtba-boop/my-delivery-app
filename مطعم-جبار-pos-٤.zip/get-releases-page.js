import { exec } from 'child_process';

const url = 'https://f-droid.org/';

console.log('Fetching F-Droid HTML...');
exec(`curl -L -A "Mozilla/5.0" "${url}"`, (error, stdout, stderr) => {
  if (error) {
    console.error(`exec error: ${error}`);
    return;
  }
  
  console.log('HTML size:', stdout.length);
});
