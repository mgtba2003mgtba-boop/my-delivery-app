import fs from 'fs';
import path from 'path';

const filePath = path.join(process.cwd(), 'public', 'jabar_drivers.apk');
if (fs.existsSync(filePath)) {
  const content = fs.readFileSync(filePath, 'utf8');
  console.log('Trimmed head (first 500 chars):');
  console.log(content.trim().substring(0, 500));
} else {
  console.log('File does not exist!');
}
