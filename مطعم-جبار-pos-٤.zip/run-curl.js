import { exec } from 'child_process';

const urls = [
  'https://raw.githubusercontent.com/lucasg/DefaultWebView/master/DefaultWebView.apk',
  'https://raw.githubusercontent.com/lucasg/DefaultWebView/main/DefaultWebView.apk'
];

urls.forEach(url => {
  console.log(`Running curl check on: ${url}`);
  exec(`curl -I -L -A "Mozilla/5.0" "${url}"`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error for ${url}: ${error}`);
      return;
    }
    console.log(`--- Result for ${url} ---`);
    console.log(stdout);
  });
});
