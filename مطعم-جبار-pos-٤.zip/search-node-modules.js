import fs from 'fs';
import path from 'path';

function findApkFiles(dir, filesList = []) {
  if (!fs.existsSync(dir)) return filesList;
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const filePath = path.join(dir, file);
    if (filePath.includes('node_modules')) {
      // skip heavy scanning, or scan specifically? No, node_modules is where we want to find files!
    }
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
      if (file !== '.git' && file !== '.next' && file !== 'dist') {
        findApkFiles(filePath, filesList);
      }
    } else {
      if (file.endsWith('.apk')) {
        filesList.push(filePath);
      }
    }
  }
  return filesList;
}

console.log('Scanning directories relative to root first...');
const localApks = findApkFiles(process.cwd());
console.log('Found local APKs:', localApks);
