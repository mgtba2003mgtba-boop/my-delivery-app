# Security Specification for Restaurant POS

## Data Invariants
1. A menuItem must have a name and a positive price.
2. A category must have a name.
3. An order must have at least one item and a timestamp.
4. Settings can only be modified by an authorized administrator.

## The "Dirty Dozen" Payloads (Denial Tests)
1. { "name": "Fake", "price": -100 } to /menuItems - INVALID_PRICE
2. { "id": "admin", "isAdmin": true } to /users/hacker - PRIVILEGE_ESCALATION
3. { "items": [] } to /orders - EMPTY_ORDER
4. { "restaurantName": "" } to /settings/config - INVALID_SETTING
5. Deleting /settings/config by a staff member - UNAUTHORIZED_DELETE
6. Updating an order's timestamp to the future - TEMPORAL_INTEGRITY
7. Injecting 2MB string into category name - RESOURCE_POISONING
8. Creating a category without an icon - SCHEMA_MISSING_FIELD
9. Modifying an order after 2 hours (simulated) - STATE_LOCKING
10. Setting price as "string" - TYPE_MISMATCH
11. Path poisoning: /orders/../settings/config - PATH_TRAVERSAL
12. Bulk reading /orders without authentication - PRIVACY_LEAK
