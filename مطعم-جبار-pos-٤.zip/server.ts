import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Log summary of orders if needed (optional backend logic)
  app.post("/api/log", (req, res) => {
    console.log("Server Log:", req.body);
    res.json({ success: true });
  });

  // Serve the actual verified Android APK file
  app.get("/jabar_drivers.apk", (req, res) => {
    const possiblePaths = [
      path.join(process.cwd(), "public", "jabar_drivers.apk"),
      path.join(process.cwd(), "dist", "jabar_drivers.apk"),
      path.join(process.cwd(), "jabar_drivers.apk"),
    ];

    let resolvedPath = "";
    for (const p of possiblePaths) {
      if (fs.existsSync(p)) {
        resolvedPath = p;
        break;
      }
    }

    if (resolvedPath) {
      console.log(`[APK Serve] Serving APK from: ${resolvedPath}`);
      res.setHeader("Content-Type", "application/vnd.android.package-archive");
      res.setHeader("Content-Disposition", 'attachment; filename="jabar_drivers.apk"');
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.sendFile(resolvedPath);
    } else {
      console.error(`[APK Error] APK file not found at searched paths: ${JSON.stringify(possiblePaths)}`);
      res.status(404).send("ملف التطبيق غير موجود حالياً على الخادم. يرجى التواصل مع إدارة المطعم.");
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "custom",
    });
    app.use(vite.middlewares);

    app.get('*', async (req, res, next) => {
      const url = req.originalUrl;
      if (url.startsWith('/api') || url.includes('.')) {
        return next();
      }
      try {
        const fs = await import('fs');
        let template = fs.readFileSync(path.resolve(process.cwd(), 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    
    // Serve static files with custom headers to prevent PWA caching delays
    app.use(express.static(distPath, {
      setHeaders: (res, filePath) => {
        const filename = path.basename(filePath);
        if (filename === 'index.html' || filename === 'sw.js' || filename.startsWith('workbox-')) {
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
        } else if (filePath.includes('/assets/')) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        } else {
          res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
        }
      }
    }));

    // Server fallback route for client side React Router SPA
    app.get('*', (req, res) => {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT} in ${process.env.NODE_ENV || 'development'} mode`);
  });
}

startServer();
