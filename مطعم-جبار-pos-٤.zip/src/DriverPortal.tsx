import React, { useState, useEffect } from "react";
import { 
  Truck, 
  User, 
  Phone, 
  MapPin, 
  Check, 
  Clock, 
  LogOut, 
  PhoneCall, 
  Map, 
  ArrowLeft, 
  Hash, 
  ShoppingBag, 
  RefreshCw, 
  AlertCircle,
  TrendingUp,
  X,
  Plus,
  Copy,
  Globe,
  ExternalLink
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  collection, 
  onSnapshot, 
  doc, 
  query, 
  where, 
  updateDoc, 
  setDoc 
} from "firebase/firestore";
import { db } from "./lib/firebase";
import { safeLocalStorage } from "./lib/storage";

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface OrderRecord {
  id: string;
  items: CartItem[];
  total: number;
  timestamp: number;
  createdBy: string;
  shift: string;
  orderType: "سفري" | "صالة" | "توصيل";
  secretCode: string;
  status?: 'pending' | 'preparing' | 'on_way' | 'delivered' | 'completed';
  deliveryDriver?: string;
  details?: {
    tableNumber?: string;
    customerName?: string;
    customerPhone?: string;
    customerAddress?: string;
    deliveryFee?: number;
    orderNotes?: string;
  };
  metadata?: {
    driverSettled?: boolean;
    settledAt?: number | null;
    settledBy?: string;
    deliveredAt?: number;
  };
}

interface DriverProfile {
  name: string;
  phone: string;
}

export default function DriverPortal() {
  const [currentDriver, setCurrentDriver] = useState<DriverProfile | null>(() => {
    const saved = safeLocalStorage.getItem("driver_profile");
    return saved ? JSON.parse(saved) : null;
  });

  const [deliveryDrivers, setDeliveryDrivers] = useState<DriverProfile[]>([]);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Form State for Login/Registration
  const [formName, setFormName] = useState("");
  const [formPhone, setFormPhone] = useState("");
  const [showRegisterConfirm, setShowRegisterConfirm] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  // Portal UI Tab
  const [activeTab, setActiveTab] = useState<"available" | "my_active" | "history">("available");

  // Filtering lists
  const availableOrders = orders.filter(
    o => (!o.deliveryDriver || o.deliveryDriver === "") && 
         (o.status === "preparing" || o.status === "pending" || !o.status || o.status === "on_way")
  );

  const myActiveOrders = currentDriver 
    ? orders.filter(o => o.deliveryDriver === currentDriver.name && o.status !== "delivered" && o.status !== "completed")
    : [];

  const myHistoryOrders = currentDriver
    ? orders.filter(o => o.deliveryDriver === currentDriver.name && (o.status === "delivered" || o.status === "completed"))
    : [];

  // دالة ذكية لتحديد ما إذا كان العنوان رابط خرائط مباشر أم نص عادي، وتسهيل عرضه كزر تفاعلي للسائق
  const getAddressLink = (address: string): string => {
    if (!address) return "";
    const trimmed = address.trim();
    // إذا كان العنوان يحتوي على رابط مباشر بالفعل
    const match = trimmed.match(/https?:\/\/[^\s]+/);
    if (match) return match[0];
    if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.includes("maps.google") || trimmed.includes("goo.gl")) {
      return trimmed;
    }
    // وإلا، نقوم بإنشاء رابط بحث تلقائي في خرائط جوجل بالعنوان النصي المكتوب لراحة السائق
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(trimmed)}`;
  };

  const isAddressUrl = (address: string): boolean => {
    if (!address) return false;
    const trimmed = address.trim();
    return trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.includes("maps.google") || trimmed.includes("goo.gl") || trimmed.includes("maps.app.goo.gl");
  };

  // تم تعطيل وإزالة خيارات التنزيل المباشر وملفات الـ APK بطلب من المستخدم للاكتفاء بتغليف الموقع عبر الـ WebView

  // دالة ذكية لاستخراج كلمات العناوين المفتاحية لتحديد الطلبيات القريبة من بعضها
  const getAddressKeywords = (address: string): string[] => {
    if (!address) return [];
    
    // توحيد الحروف العربية لتفادي اختلافات الكتابة ولمطابقة دقيقة
    const normalized = address
      .toLowerCase()
      .trim()
      .replace(/[أإآ]/g, "ا")
      .replace(/ة/g, "ه")
      .replace(/ى/g, "ي")
      .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, " ");
    
    const words = normalized.split(/\s+/);
    
    // الكلمات الشائعة التي لا تدل على اسم المنطقة ونريد استبعادها
    const stopWords = [
      "حي", "شارع", "الشارع", "قرب", "مقابل", "خلف", "منطقه", "منطقة", 
      "محله", "محلة", "زقاق", "دار", "بيت", "فرع", "مجاور", "بجانب", 
      "في", "على", "العراق", "بغداد", "بين", "تقاطع", "ساحة", "سوق", "عمارة",
      "قريب", "من", "الرئيسي", "الفرعي", "رقم", "شقة", "طابق"
    ];
    
    return words
      .map(w => w.startsWith("ال") ? w.substring(2) : w) // إزالة ال التعريف لمطابقة العبارات بدقة
      .filter(w => w.length >= 3 && !stopWords.includes(w) && !/^\d+$/.test(w)); // التصفية
  };

  // تصفية وحساب المجموعات المتجاورة (Clusters) من الطلبيات الجاهزة المتوفرة
  const availableClusters = React.useMemo(() => {
    const map: { [key: string]: OrderRecord[] } = {};
    
    availableOrders.forEach(order => {
      const address = order.details?.customerAddress || "";
      const keywords = getAddressKeywords(address);
      keywords.forEach(kw => {
        if (!map[kw]) map[kw] = [];
        if (!map[kw].some(o => o.id === order.id)) {
          map[kw].push(order);
        }
      });
    });

    return Object.keys(map)
      .map(kw => {
        // البحث عن أفضل صيغة للاسم من العنوان لعرضها (مثلاً إعادة "ال" التعريف إذا كانت موجودة أصلاً)
        let displayLabel = kw;
        for (const order of map[kw]) {
          const addr = order.details?.customerAddress || "";
          const match = addr.match(new RegExp(`(\\bال)?${kw}\\w*`, "i"));
          if (match) {
            displayLabel = match[0];
            break;
          }
        }

        return {
          keyword: kw,
          displayLabel,
          orders: map[kw],
          orderIds: map[kw].map(o => o.id)
        };
      })
      .filter(c => c.orders.length >= 2) // يجب أن تضم المجموعة طلبين على الأقل
      .sort((a, b) => b.orders.length - a.orders.length);
  }, [availableOrders]);

  // تصفية طلبياتي النشطة وتحديد إن كان هناك طلبيات متجاورة بنفس المنطقة
  const activeClusters = React.useMemo(() => {
    const map: { [key: string]: OrderRecord[] } = {};
    
    myActiveOrders.forEach(order => {
      const address = order.details?.customerAddress || "";
      const keywords = getAddressKeywords(address);
      keywords.forEach(kw => {
        if (!map[kw]) map[kw] = [];
        if (!map[kw].some(o => o.id === order.id)) {
          map[kw].push(order);
        }
      });
    });

    return Object.keys(map)
      .map(kw => {
        let displayLabel = kw;
        for (const order of map[kw]) {
          const addr = order.details?.customerAddress || "";
          const match = addr.match(new RegExp(`(\\bال)?${kw}\\w*`, "i"));
          if (match) {
            displayLabel = match[0];
            break;
          }
        }
        return {
          keyword: kw,
          displayLabel,
          orders: map[kw],
          orderIds: map[kw].map(o => o.id)
        };
      })
      .filter(c => c.orders.length >= 2);
  }, [myActiveOrders]);

  // دالة لاستلام كافة طلبيات المنطقة المتقاربة دفعة واحدة بنقرة واحدة
  const handlePickCluster = async (orderIds: string[], clusterName: string) => {
    if (!currentDriver) return;
    if (!window.confirm(`هل تود استلام كافة الطلبات القريبة جداً في منطقة (${clusterName}) معاً؟ (العدد: ${orderIds.length})`)) {
      return;
    }
    
    try {
      const promises = orderIds.map(orderId => 
        updateDoc(doc(db, "orders", orderId), {
          deliveryDriver: currentDriver.name,
          status: "on_way"
        })
      );
      await Promise.all(promises);
      alert(`👍 تم استلام كافة طلبيات منطقة (${clusterName}) بنجاح! اذهب لعلامة "طلباتي النشطة" لتوصيلها معاً في جولة واحدة.`);
    } catch (err) {
      alert("عذراً، حدث خطأ أثناء استلام بعض طلبيات هذه المجموعة.");
    }
  };

  // Load config drivers and listen to orders
  useEffect(() => {
    // 1. Listen to drivers configuration
    const unsubConfig = onSnapshot(doc(db, "settings", "config"), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        const rawDrivers = data.deliveryDrivers || [];
        const normalized = rawDrivers.map((d: any) => {
          if (typeof d === "string") return { name: d, phone: "" };
          return d;
        });
        setDeliveryDrivers(normalized);
      }
    });

    // 2. Listen to delivery orders
    const q = query(collection(db, "orders"), where("orderType", "==", "توصيل"));
    const unsubOrders = onSnapshot(q, (snapshot) => {
      const ords = snapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() } as OrderRecord));
      // Sort desc by timestamp
      ords.sort((a, b) => b.timestamp - a.timestamp);
      setOrders(ords);
      setLoading(false);
    }, (err) => {
      console.error("Error loading delivery orders:", err);
      setLoading(false);
    });

    return () => {
      unsubConfig();
      unsubOrders();
    };
  }, []);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    const nameTrimmed = formName.trim();
    const phoneTrimmed = formPhone.trim();

    if (!nameTrimmed) {
      setErrorMessage("الرجاء إدخال الاسم المعتمد");
      return;
    }
    if (!phoneTrimmed) {
      setErrorMessage("الرجاء إدخال رقم الهاتف");
      return;
    }

    // Try finding exact driver
    const found = deliveryDrivers.find(
      d => d.name.toLowerCase() === nameTrimmed.toLowerCase() || d.phone === phoneTrimmed
    );

    if (found) {
      // Exist already
      const profile = { name: found.name, phone: found.phone || phoneTrimmed };
      setCurrentDriver(profile);
      safeLocalStorage.setItem("driver_profile", JSON.stringify(profile));
    } else {
      // Prompt self-registration
      setShowRegisterConfirm(true);
    }
  };

  const handleSelfRegister = async () => {
    try {
      const newDriver: DriverProfile = {
        name: formName.trim(),
        phone: formPhone.trim()
      };

      const updatedDrivers = [...deliveryDrivers, newDriver];
      
      // Update in database configuration
      await setDoc(doc(db, "settings", "config"), { deliveryDrivers: updatedDrivers }, { merge: true });

      setCurrentDriver(newDriver);
      safeLocalStorage.setItem("driver_profile", JSON.stringify(newDriver));
      setShowRegisterConfirm(false);
      setFormName("");
      setFormPhone("");
    } catch (err) {
      console.error("Register Error:", err);
      setErrorMessage("حدث خطأ أثناء التسجيل. يرجى المحاولة لاحقاً.");
    }
  };

  const handleLogout = () => {
    if (window.confirm("هل أنت متأكد من تسجيل الخروج؟")) {
      setCurrentDriver(null);
      safeLocalStorage.removeItem("driver_profile");
      setActiveTab("available");
    }
  };

  // Assign Order to Driver
  const handlePickOrder = async (orderId: string) => {
    if (!currentDriver) return;
    try {
      await updateDoc(doc(db, "orders", orderId), {
        deliveryDriver: currentDriver.name,
        status: "on_way"
      });
    } catch (err) {
      alert("عذراً، لم تنجح عملية استلام الطلب. يرجى المحاولة مجدداً.");
    }
  };

  // Mark Order as Delivered
  const handleDeliverOrder = async (orderId: string) => {
    try {
      await updateDoc(doc(db, "orders", orderId), {
        status: "delivered",
        "metadata.driverSettled": false, // Marks as unsettled for driver cash
        "metadata.deliveredAt": Date.now()
      });
    } catch (err) {
      alert("فشل تحديث حالة الطلب.");
    }
  };

  // Re-release Order back to preparing
  const handleReleaseOrder = async (orderId: string) => {
    if (window.confirm("هل أنت متأكد من إرجاع الطلب للمطبخ مجدداً وإخراجه من ذمتك؟")) {
      try {
        await updateDoc(doc(db, "orders", orderId), {
          deliveryDriver: "",
          status: "preparing"
        });
      } catch (err) {
        alert("فشل إرجاع الطلب.");
      }
    }
  };

  // Statistics
  const totalSettledToday = myHistoryOrders
    .filter(o => o.metadata?.driverSettled)
    .reduce((sum, o) => sum + o.total, 0);

  const totalUnsettledToday = myHistoryOrders
    .filter(o => !o.metadata?.driverSettled)
    .reduce((sum, o) => sum + o.total, 0);

  const totalEarnings = myHistoryOrders.reduce((sum, o) => sum + (o.details?.deliveryFee || 0), 0);

  // حالات ذكية لتحديد حجم الشاشة ونظام التشغيل الخاص بالمستخدم ومحاكاة الأجهزة
  const [isMobileViewport, setIsMobileViewport] = useState(false);
  const [selectedFrame, setSelectedFrame] = useState<"iphone" | "android" | "fullscreen">("iphone");
  const [detectedOS, setDetectedOS] = useState("جاري الكشف...");
  const [simulatedTime, setSimulatedTime] = useState("12:00");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setSimulatedTime(now.toLocaleTimeString("ar-IQ", { hour: "2-digit", minute: "2-digit", hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const checkViewportAndOS = () => {
      const ua = navigator.userAgent.toLowerCase();
      const isIos = /iphone|ipad|ipod/.test(ua);
      const isAndroid = /android/.test(ua);
      const isMobile = isIos || isAndroid || (window.innerWidth <= 500);
      
      setIsMobileViewport(isMobile);

      if (isIos) {
        setDetectedOS("آيفون (iOS) 🍏");
        setSelectedFrame("fullscreen");
      } else if (isAndroid) {
        setDetectedOS("أندرويد (Android) 🤖");
        setSelectedFrame("fullscreen");
      } else {
        setDetectedOS("كمبيوتر (معاينة)");
      }
    };

    checkViewportAndOS();
    window.addEventListener("resize", checkViewportAndOS);
    return () => window.removeEventListener("resize", checkViewportAndOS);
  }, []);

  const renderPortalContent = () => {
    return (
      <div className="flex-1 overflow-y-auto overflow-x-hidden" style={{ scrollbarWidth: "none" }}>
        {/* Header section */}
        <header className="sticky top-0 z-50 bg-zinc-900 text-white shadow-xl rounded-b-[2rem] px-5 py-4 flex justify-between items-center flex-row-reverse">
        {currentDriver ? (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500/15 border border-amber-500/20 text-amber-500 rounded-2xl flex items-center justify-center shadow-inner">
              <Truck size={18} />
            </div>
            <div className="text-right">
              <p className="text-[10px] text-amber-400 font-black leading-none mb-1">الكابتن النشط 🛵</p>
              <h3 className="text-xs font-black text-white leading-none">{currentDriver.name}</h3>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 flex-row-reverse text-right">
            <Truck size={20} className="text-amber-500" />
            <h1 className="text-base font-black tracking-tight text-white">بوابة الكابتن السائق</h1>
          </div>
        )}

        <div className="text-left">
          <span className="text-[11px] font-black text-amber-400 tracking-wider bg-white/5 px-3 py-1.5 rounded-xl border border-white/5">مطعم جبار 🛵</span>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-md mx-auto px-4 mt-6">

        {/* LOGIN SCREEN */}
        {!currentDriver && (
          <div className="bg-white border border-zinc-200 shadow-xl rounded-[2.5rem] p-7 text-right mt-12">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-amber-500/10 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Truck size={32} />
              </div>
              <h2 className="text-lg font-black text-zinc-900">تسجيل دخول السائق</h2>
              <p className="text-xs text-zinc-400 mt-1 font-bold">بوابة استلام طلبيات الدليفري وتتبع الحسابات</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-black text-zinc-500 mb-1 block mr-1">الاسم الكامل 👤</label>
                <input
                  type="text"
                  required
                  placeholder="اكتب اسمك الثلاثي المعتمد..."
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-2xl text-xs text-right focus:outline-none focus:border-amber-500 focus:bg-white transition-all"
                />
              </div>

              <div>
                <label className="text-xs font-black text-zinc-500 mb-1 block mr-1">رقم الهاتف 📞</label>
                <input
                  type="tel"
                  required
                  placeholder="رقم الهاتف (مثال: 07700000000)..."
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-2xl text-xs text-right font-mono focus:outline-none focus:border-amber-500 focus:bg-white transition-all"
                />
              </div>

              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs font-bold flex items-center gap-2">
                  <AlertCircle size={14} className="shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black py-4.5 rounded-2xl text-xs transition-all flex items-center justify-center gap-2 shadow-md active:scale-95 text-center cursor-pointer"
              >
                دخول البوابة <Check size={16} />
              </button>
            </form>

            {/* Self-register Confirmation Pop-up */}
            <AnimatePresence>
              {showRegisterConfirm && (
                <>
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onClick={() => setShowRegisterConfirm(false)}
                    className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
                  />
                  <motion.div
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.95, opacity: 0 }}
                    className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[88%] bg-white rounded-[2rem] p-6 z-[60] shadow-2xl text-right"
                  >
                    <div className="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-full flex items-center justify-center mb-3">
                      <Truck size={24} />
                    </div>
                    <h3 className="text-md font-black text-zinc-950">سائق جديد؟ 😊</h3>
                    <p className="text-xs text-zinc-500 font-bold mt-2 leading-relaxed">
                      اسمك أو رقم هاتفك غير مسجل في النظام مسبقاً. هل تود تسجيل نفسك الآن كسائق جديد للانضمام للفريق وتلقي الطلبيات فوراً؟
                    </p>

                    <div className="mt-5 grid grid-cols-2 gap-3.5">
                      <button
                        onClick={handleSelfRegister}
                        className="bg-amber-500 hover:bg-amber-600 font-black text-zinc-950 py-3 rounded-xl text-xs transition-all active:scale-95"
                      >
                        نعم، سجلني
                      </button>
                      <button
                        onClick={() => setShowRegisterConfirm(false)}
                        className="bg-zinc-100 hover:bg-zinc-200 font-bold text-zinc-650 py-3 rounded-xl text-xs transition-all active:scale-95"
                      >
                        إلغاء
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* LOGGED IN PORTAL VIEW */}
        {currentDriver && (
          <div className="space-y-6">
            
            {/* Quick Summary Widgets */}
            <div className="grid grid-cols-3 gap-2">
              <div 
                onClick={() => setActiveTab("available")}
                className={`p-3.5 rounded-2xl text-center border cursor-pointer transition-all ${
                  activeTab === "available"
                    ? "bg-amber-500/15 border-amber-300 shadow-sm"
                    : "bg-white border-zinc-200 hover:border-zinc-300"
                }`}
              >
                <div className="relative inline-block">
                  <ShoppingBag size={18} className="text-amber-500 mx-auto" />
                  {availableOrders.length > 0 && (
                    <span className="absolute -top-1.5 -right-2 bg-amber-600 text-white text-[9px] font-black rounded-full w-4 h-4 flex items-center justify-center">
                      {availableOrders.length}
                    </span>
                  )}
                </div>
                <p className="text-[10px] font-black text-zinc-500 mt-1">طلبات جاهزة</p>
              </div>

              <div 
                onClick={() => setActiveTab("my_active")}
                className={`p-3.5 rounded-2xl text-center border cursor-pointer transition-all ${
                  activeTab === "my_active"
                    ? "bg-blue-500/10 border-blue-300 shadow-sm"
                    : "bg-white border-zinc-200 hover:border-zinc-300"
                }`}
              >
                <div className="relative inline-block">
                  <Truck size={18} className="text-blue-500 mx-auto" />
                  {myActiveOrders.length > 0 && (
                    <span className="absolute -top-1.5 -right-2 bg-blue-600 text-white text-[9px] font-black rounded-full w-4 h-4 flex items-center justify-center">
                      {myActiveOrders.length}
                    </span>
                  )}
                </div>
                <p className="text-[10px] font-black text-zinc-500 mt-1">طلباتي النشطة</p>
              </div>

              <div 
                onClick={() => setActiveTab("history")}
                className={`p-3.5 rounded-2xl text-center border cursor-pointer transition-all ${
                  activeTab === "history"
                    ? "bg-emerald-500/10 border-emerald-300 shadow-sm"
                    : "bg-white border-zinc-200 hover:border-zinc-300"
                }`}
              >
                <TrendingUp size={18} className="text-emerald-500 mx-auto" />
                <p className="text-[10px] font-black text-zinc-500 mt-1">سجل التوصيل</p>
              </div>
            </div>

            {/* Content Area according to Tabs */}

            {/* 1. Available Orders */}
            {activeTab === "available" && (
              <div className="space-y-4">
                <div className="flex justify-between items-center text-right">
                  <h4 className="text-xs font-black text-zinc-400">الطلبات الجاهزة بانتظار سائق ({availableOrders.length})</h4>
                  {loading && <RefreshCw size={12} className="animate-spin text-zinc-400" />}
                </div>

                {/* لوحة مقترحات تجميع الطلبيات المتقاربة جداً لمشوار توصيل مشترك */}
                {availableClusters.length > 0 && (
                  <div className="bg-gradient-to-r from-emerald-500/10 to-amber-500/10 border border-emerald-500/20 rounded-[2rem] p-4.5 text-right space-y-3">
                    <div className="flex justify-between items-center flex-row-reverse">
                      <div className="flex items-center gap-1.5 flex-row-reverse text-emerald-800 font-black text-xs">
                        <MapPin size={16} className="text-emerald-600 animate-bounce" />
                        <span>💡 مقترحات التوصيل المشترك (طلبات متقاربة):</span>
                      </div>
                      <span className="text-[10px] text-emerald-600 font-extrabold animate-pulse">وفر البنزين والوقت 🛵</span>
                    </div>
                    
                    <p className="text-[10px] text-zinc-550 font-bold leading-relaxed pr-1 text-zinc-650">
                      تم رصد طلبيات متجهة لنفس المنطقة أو المعالم المجاورة. نوصي باستلامها معاً وإيصالها بطلعة واحدة لتوفير الجهد الشديد وزيادة أرباحك!
                    </p>

                    <div className="space-y-2">
                      {availableClusters.map((cluster, cIdx) => (
                        <div 
                          key={cIdx}
                          className="bg-white/95 border border-emerald-500/15 rounded-2xl p-3 flex justify-between items-center flex-row gap-3 shadow-sm hover:border-emerald-400 transition-colors"
                        >
                          <button
                            onClick={() => handlePickCluster(cluster.orderIds, cluster.displayLabel)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[9.5px] px-3 py-2 rounded-xl active:scale-95 transition-all shadow-sm cursor-pointer whitespace-nowrap"
                          >
                            استلام الـ {cluster.orders.length} معاً 🏁
                          </button>
                          
                          <div className="text-right min-w-0 flex-1">
                            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 font-black text-[9px] px-2.5 py-1 rounded-lg mb-1">
                              📍 منطقة: {cluster.displayLabel}
                            </span>
                            <div className="text-[9.5px] text-zinc-500 font-bold truncate">
                              زبائن المنطقة: {cluster.orders.map(o => o.details?.customerName || "مجهول").join(" • ")}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {availableOrders.length === 0 ? (
                  <div className="p-12 text-center bg-white border border-dashed border-zinc-200 rounded-[2rem]">
                    <ShoppingBag size={32} className="text-zinc-200 mx-auto mb-2" />
                    <p className="text-xs font-bold text-zinc-400">لا توجد طلبيات توصيل جاهزة حالياً</p>
                    <p className="text-[10px] text-zinc-350 mt-1">سيتم إدراج أي طلب دليفري جديد يُجهزه المطعم هنا مباشرة</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {availableOrders.map((order) => {
                      const dateStr = new Date(order.timestamp).toLocaleString("ar-IQ", {
                        hour: "2-digit",
                        minute: "2-digit"
                      });

                      const matchingClusters = availableClusters.filter(c => c.orderIds.includes(order.id));

                      return (
                        <div 
                          key={order.id}
                          className="bg-white border border-zinc-200 rounded-[2rem] p-4 shadow-sm space-y-3 hover:border-amber-400 transition-colors"
                        >
                          <div className="flex justify-between items-center flex-row shadow-sm bg-zinc-50 p-2 rounded-xl text-right">
                            <span className="font-mono text-[9px] text-zinc-450 font-bold bg-zinc-200/60 px-2 py-0.5 rounded-md">رمز: {order.secretCode || "N/A"}</span>
                            <span className="text-[10px] font-bold text-zinc-400">{dateStr}</span>
                          </div>

                          <div className="text-right space-y-1">
                            <p className="text-xs font-black text-zinc-900 leading-none">
                              العميل: {order.details?.customerName || "زبون مجهول"}
                            </p>
                            
                            {order.details?.customerAddress ? (
                              <div className="mt-1 space-y-1 bg-zinc-50 p-2.5 rounded-xl border border-zinc-100/80 text-right">
                                <div className="text-[10px] text-zinc-650 font-bold leading-normal">
                                  📍 العنوان: <span className="text-zinc-900 font-black">{order.details.customerAddress}</span>
                                </div>
                                <a 
                                  href={getAddressLink(order.details.customerAddress)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-zinc-950 font-black text-[9.5px] rounded-lg transition-all active:scale-95 shadow-sm mt-1 cursor-pointer w-full justify-center"
                                >
                                  <MapPin size={11} />
                                  <span>{isAddressUrl(order.details.customerAddress) ? "فتح خرائط الموقع المباشر 🗺️" : "بحث تلقائي عن العنوان بالخرائط 🗺️"}</span>
                                </a>
                              </div>
                            ) : (
                              <p className="text-[10.5px] text-zinc-400 font-bold">📍 العنوان: لم يذكر بالتحديد</p>
                            )}
                            
                            {/* إشارة للمنطقة المجاورة أو المتجاورة */}
                            {matchingClusters.length > 0 && (
                              <div className="inline-flex items-center gap-1 mt-1 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-100/80 text-emerald-700 text-[9px] font-black">
                                <span className="inline-block w-1 h-1 rounded-full bg-emerald-500 animate-pulse"></span>
                                <span>متقارب مع طلبيات جاهزة أخرى في منطقة ({matchingClusters.map(c => c.displayLabel).join("، ")})</span>
                              </div>
                            )}

                            {order.details?.orderNotes && (
                              <p className="text-[9px] text-red-550 font-black leading-none mt-1">
                                ⚠️ ملاحظة: {order.details?.orderNotes}
                              </p>
                            )}
                          </div>

                          {/* Order items briefing */}
                          <div className="space-y-1 bg-zinc-50 p-2.5 rounded-xl text-xs pr-3 border-r-2 border-r-amber-500 text-right">
                            {order.items?.map((item, idx) => (
                              <div key={idx} className="flex justify-between text-[11px] text-zinc-600 font-bold">
                                <span className="text-zinc-400 text-[10px]">x{item.quantity}</span>
                                <span>{item.name}</span>
                              </div>
                            ))}
                          </div>

                          <div className="flex justify-between items-center pt-2 border-t border-zinc-100 flex-row">
                            <button
                              onClick={() => handlePickOrder(order.id)}
                              className="bg-amber-500 hover:bg-amber-600 text-zinc-950 px-4 py-2.5 rounded-xl text-[10px] font-bold transition-all active:scale-95 shadow flex items-center gap-1.5 cursor-pointer"
                            >
                              <Truck size={12} />
                              استلام الطلب ⏎
                            </button>
                            <div className="text-right">
                              <p className="text-[9px] text-zinc-400 leading-none mb-0.5">مجموع الحساب</p>
                              <p className="font-mono font-black text-xs text-zinc-900">{order.total.toLocaleString()} د.ع</p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* 2. My Active Orders */}
            {activeTab === "my_active" && (
              <div className="space-y-4">
                <h4 className="text-xs font-black text-zinc-400">طلباتي النشطة قيد التوصيل ({myActiveOrders.length})</h4>

                {/* تنبيه ذكي عند وجود طلبيات متقاطعة / متقاربة قيد التوصيل لدى السائق نفسه */}
                {activeClusters.length > 0 && (
                  <div className="bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-[2rem] p-4 text-right space-y-2">
                    <div className="flex items-center gap-1.5 flex-row-reverse text-blue-800 font-black text-xs">
                      <MapPin size={16} className="text-blue-600 animate-pulse" />
                      <span>💡 خطة فرز التوصيل المشترك:</span>
                    </div>
                    <p className="text-[10px] text-zinc-650 font-bold leading-relaxed">
                      لديك طلبيات متعددة بذمتك متجهة حالياً لنفس المنطقة بالتوازي! نوصي بالتوجه لهذه الوجهات لتسليمهم سوية في دورة واحدة:
                    </p>
                    <div className="flex flex-wrap gap-1.5 justify-end">
                      {activeClusters.map((cluster, idx) => (
                        <span key={idx} className="bg-blue-100 text-blue-800 text-[9px] font-black px-2.5 py-1 rounded-full border border-blue-200 shadow-xs">
                          📍 {cluster.displayLabel} ({cluster.orders.length} طلبات معاً)
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {myActiveOrders.length === 0 ? (
                  <div className="p-12 text-center bg-white border border-dashed border-zinc-200 rounded-[2rem]">
                    <Truck size={32} className="text-zinc-200 mx-auto mb-2" />
                    <p className="text-xs font-bold text-zinc-400">لا توجد طلبيات مستلمة بذمتك الآن</p>
                    <p className="text-[10px] text-zinc-350 mt-1">اذهب لعلامة "طلبات جاهزة" واستلم الطلبات لتظهر هنا</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {myActiveOrders.map((order) => {
                      const matchingClusters = activeClusters.filter(c => c.orderIds.includes(order.id));

                      return (
                        <div 
                          key={order.id}
                          className="bg-white border-2 border-blue-400/80 rounded-[2rem] p-5 shadow-sm space-y-4"
                        >
                          <div className="flex justify-between items-center flex-row pb-2 border-b border-zinc-100 text-right">
                            <span className="font-mono text-[9px] text-zinc-450 font-bold bg-zinc-100 px-2 py-0.5 rounded-md">رمز: {order.secretCode || "N/A"}</span>
                            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg flex items-center gap-1">
                              🛵 جاري التوصيل
                            </span>
                          </div>

                          <div className="text-right space-y-2">
                            <div className="flex justify-between items-start flex-row-reverse text-right">
                              <div className="flex-1 min-w-0 pr-1 text-right">
                                <p className="text-xs font-black text-zinc-950">{order.details?.customerName || "زبون مجهول"}</p>
                                <p className="text-[10px] font-mono text-zinc-500 font-bold mt-0.5">{order.details?.customerPhone || "لا يوجد هاتف"}</p>
                              </div>
                              {order.details?.customerPhone && (
                                <a 
                                  href={`tel:${order.details.customerPhone}`}
                                  className="w-8 h-8 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center transition-colors shadow-sm cursor-pointer border border-emerald-100"
                                >
                                  <PhoneCall size={14} />
                                </a>
                              )}
                            </div>

                            {order.details?.customerAddress ? (
                              <div className="space-y-1.5 bg-zinc-50 p-3 rounded-2xl border border-zinc-150 text-right w-full">
                                <div className="text-xs text-zinc-700 font-bold leading-relaxed">
                                  📍 العنوان: <span className="text-zinc-950 font-black">{order.details.customerAddress}</span>
                                </div>
                                <a 
                                  href={getAddressLink(order.details.customerAddress)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-2 justify-center w-full px-3 py-2 bg-amber-500 hover:bg-amber-600 active:scale-95 text-zinc-950 font-black text-xs rounded-xl shadow transition-all cursor-pointer"
                                >
                                  <MapPin size={12} className="shrink-0" />
                                  <span>{isAddressUrl(order.details.customerAddress) ? "الانتقال للموقع على الخريطة 🗺️" : "بحث تلقائي عن العنوان بالخرائط 🗺️"}</span>
                                </a>
                              </div>
                            ) : (
                              <p className="text-xs text-zinc-400 font-bold">📍 العنوان: لم يتم تحديد العنوان</p>
                            )}

                            {/* تنبيه بالطلبات المناظرة قيد التوصيل لدى السائق نفسه */}
                            {matchingClusters.length > 0 && (
                              <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-[9px] font-black w-full justify-start">
                                <span className="inline-block w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping"></span>
                                <span>لديك طلبيات نشطة متقاربة في نفس المنطقة ({matchingClusters.map(c => c.displayLabel).join("، ")})</span>
                              </div>
                            )}

                            {order.details?.orderNotes && (
                              <p className="text-[10px] text-red-600 font-black bg-red-50 p-2.5 rounded-xl border border-red-100/50">
                                ⚠️ ملاحظة: {order.details?.orderNotes}
                              </p>
                            )}
                          </div>

                          {/* Items breakdown list */}
                          <div className="space-y-1 bg-zinc-50/50 p-3 rounded-2xl border border-zinc-150 text-right">
                            <p className="text-[9px] font-black text-zinc-400 mb-1 block">تتضمن الوجبة 🍔</p>
                            {order.items?.map((item, idx) => (
                              <div key={idx} className="flex justify-between text-xs text-zinc-650 font-black">
                                <span className="text-zinc-400 text-[10px]">x{item.quantity}</span>
                                <span>{item.name}</span>
                              </div>
                            ))}
                          </div>

                          {/* Call To Actions */}
                          <div className="pt-2 border-t border-zinc-100 space-y-2">
                            <div className="flex justify-between items-center text-right flex-row-reverse mb-2 bg-zinc-50 p-2 rounded-xl">
                              <div className="text-right">
                                <p className="text-[9px] text-zinc-400 font-bold leading-none mb-0.5">الحساب المطلوب</p>
                                <p className="font-mono font-black text-sm text-zinc-950">{(order.total).toLocaleString()} د.ع</p>
                              </div>
                              <div className="text-left">
                                <p className="text-[9px] text-zinc-400 font-bold leading-none mb-0.5">أجرة التوصيل الك</p>
                                <p className="text-[11px] font-black text-emerald-700">{(order.details?.deliveryFee || 0).toLocaleString()} د.ع</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2.5">
                              <button
                                onClick={() => handleReleaseOrder(order.id)}
                                className="bg-zinc-100 hover:bg-zinc-200 text-zinc-650 text-[10px] font-bold py-3.5 rounded-xl transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1 border border-zinc-200"
                              >
                                إرجاع الطلب ↺
                              </button>
                              
                              <button
                                onClick={() => handleDeliverOrder(order.id)}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black py-3.5 rounded-xl transition-all active:scale-95 flex items-center justify-center gap-1.5 shadow-md shadow-emerald-100 cursor-pointer"
                              >
                                <Check size={14} /> تم التوصيل واستلام المبلغ
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* 3. History Logs & Daily Settlement Ledger */}
            {activeTab === "history" && (
              <div className="space-y-4">
                
                {/* Visual Ledger cards */}
                <div className="bg-zinc-900 border border-zinc-800 text-white p-5 rounded-[2rem] shadow-lg text-right space-y-4">
                  <span className="text-xs font-bold text-amber-500 block mr-1">محفظتك لليوم 📋</span>
                  
                  <div className="grid grid-cols-2 gap-3 pb-3 border-b border-zinc-800">
                    <div className="text-right">
                      <p className="text-[9px] text-zinc-400 font-bold">مبالغ قمت بقبضها 💵</p>
                      <p className="text-md font-black text-amber-400 font-mono mt-0.5">
                        {(totalUnsettledToday + totalSettledToday).toLocaleString()} د.ع
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[9px] text-zinc-400 font-bold">أجرك ومجموع التوصيل 🛵</p>
                      <p className="text-md font-black text-emerald-400 font-mono mt-0.5">
                        {totalEarnings.toLocaleString()} د.ع
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="bg-red-500/10 p-2.5 rounded-xl text-right">
                      <span className="text-red-400 font-bold">بذمتك قيد التسليم (معلق):</span>
                      <p className="font-mono font-black text-white text-xs mt-0.5">{totalUnsettledToday.toLocaleString()} د.ع</p>
                    </div>
                    <div className="bg-emerald-500/10 p-2.5 rounded-xl text-right">
                      <span className="text-emerald-400 font-bold">تم قبضه وتصفيته:</span>
                      <p className="font-mono font-black text-white text-xs mt-0.5">{totalSettledToday.toLocaleString()} د.ع</p>
                    </div>
                  </div>
                </div>

                <h4 className="text-xs font-black text-zinc-400 py-1 border-b border-zinc-200">تفاصيل طلبيات هذا اليوم ({myHistoryOrders.length})</h4>

                {myHistoryOrders.length === 0 ? (
                  <div className="p-12 text-center bg-white border border-dashed border-zinc-200 rounded-[2rem]">
                    <ShoppingBag size={28} className="text-zinc-200 mx-auto mb-2" />
                    <p className="text-xs font-bold text-zinc-400">لم تقم بتسليم أي طلبات اليوم بعد</p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {myHistoryOrders.map((order) => {
                      const dateStr = order.metadata?.deliveredAt 
                        ? new Date(order.metadata.deliveredAt).toLocaleString("ar-IQ", { hour: "2-digit", minute: "2-digit" })
                        : "مكتمل";

                      return (
                        <div 
                          key={order.id}
                          className="bg-white border border-zinc-200 rounded-2xl p-3.5 flex justify-between items-center flex-row gap-3 shadow-sm hover:border-zinc-350 transition-colors"
                        >
                          <div className="text-left">
                            {order.metadata?.driverSettled ? (
                              <span className="px-2 py-1 rounded-lg text-[9px] font-bold bg-emerald-50 text-emerald-700 whitespace-nowrap">
                                مصفى ومسلم ✓
                              </span>
                            ) : (
                              <span className="px-2 py-1 rounded-lg text-[9px] font-bold bg-amber-50 text-amber-650 animate-pulse whitespace-nowrap">
                                بذمتك ⏳
                              </span>
                            )}
                          </div>

                          <div className="text-right flex-1 min-w-0">
                            <div className="flex justify-between items-center text-right flex-row-reverse mb-0.5">
                              <span className="font-mono font-black text-xs text-zinc-900">{(order.total).toLocaleString()} د.ع</span>
                              <span className="text-xs font-bold text-zinc-950 truncate flex-1 min-w-0 pr-1">{order.details?.customerName || "زبون مجهول"}</span>
                            </div>
                            <div className="flex justify-between items-center text-[10px] text-zinc-400">
                              <span>التوصيل: {(order.details?.deliveryFee || 0).toLocaleString()} د.ع</span>
                              <span>الوقت: {dateStr}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
};

  return (
    <div className="min-h-screen bg-zinc-50 font-sans text-right text-zinc-900 pb-16 flex flex-col w-full" dir="rtl">
      {renderPortalContent()}
    </div>
  );
}
