import React, { useState, useEffect, useMemo, useRef } from "react";
import { 
  ShoppingBag, 
  ChevronRight, 
  Plus, 
  Minus, 
  X, 
  Truck, 
  User, 
  Phone, 
  MapPin, 
  CheckCircle2,
  Check,
  Clock,
  ArrowLeft,
  Utensils,
  Navigation,
  Loader2,
  Search,
  Star,
  ThumbsUp,
  Heart,
  MessageSquare,
  Send,
  Sparkles,
  History,
  PhoneCall,
  ChevronLeft
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  collection, 
  onSnapshot, 
  setDoc, 
  doc, 
  query, 
  orderBy,
  addDoc,
  where,
  limit,
  getDocs
} from "firebase/firestore";
import { db, auth } from "./lib/firebase";
import { safeLocalStorage } from "./lib/storage";

// Types matching current schema
interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
  description?: string; 
  available?: boolean;
}

interface OrderRecord {
  id: string;
  items: MenuItem[];
  total: number;
  timestamp: any;
  createdBy: string;
  shift: string;
  orderType: 'توصيل' | 'صالة' | 'سفري';
  secretCode: string;
  status: 'pending' | 'preparing' | 'on_way' | 'delivered';
  deliveryDriver?: string;
  details?: {
    customerName?: string;
    customerPhone?: string;
    customerAddress?: string;
    orderNotes?: string;
    deliveryFee?: number;
  };
  metadata?: {
    deviceId?: string;
    source?: string;
    createdAt?: number;
  };
}

interface Category {
  id: string;
  name: string;
  icon: string;
}

interface CartItem extends MenuItem {
  quantity: number;
}

export default function OnlineMenu() {
  // App states
  const [categories, setCategories] = useState<Category[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [restaurantName, setRestaurantName] = useState("مطعم جبار");
  const [drivers, setDrivers] = useState<{name: string, phone: string}[]>([]);
  
  // Transition countdown states
  const [isOrdered, setIsOrdered] = useState<boolean>(() => {
    return !!safeLocalStorage.getItem('last_placed_order');
  });
  const [lastPlacedOrder, setLastPlacedOrder] = useState<any>(() => {
    try {
      const saved = safeLocalStorage.getItem('last_placed_order');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  const [countdownSeconds, setCountdownSeconds] = useState(5);
  
  // Tracking & history state
  const [activeTrackingId, setActiveTrackingId] = useState<string | null>(() => {
    return safeLocalStorage.getItem('last_order_id') || null;
  });
  const [trackedOrder, setTrackedOrder] = useState<OrderRecord | null>(null);
  const [isTrackingLoading, setIsTrackingLoading] = useState(false);
  const [previousOrders, setPreviousOrders] = useState<OrderRecord[]>([]);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  
  // Manual searching for older orders state
  const [showTrackSearch, setShowTrackSearch] = useState(false);
  const [trackPhoneInput, setTrackPhoneInput] = useState("");
  const [trackPhoneError, setTrackPhoneError] = useState("");
  const [isTrackSearchLoading, setIsTrackSearchLoading] = useState(false);

  // Form checkout inputs
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  const [orderNotes, setOrderNotes] = useState("");
  const [deliveryAreas, setDeliveryAreas] = useState<{ id: string; name: string; fee: number }[]>([]);
  const [selectedAreaId, setSelectedAreaId] = useState<string>("");
  const [selectedAreaFee, setSelectedAreaFee] = useState<number>(0);
  const [isLocating, setIsLocating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Feedback states in Delivered view
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [platformRating, setPlatformRating] = useState<number>(5);
  const [tasteRating, setTasteRating] = useState<number>(5);
  const [serviceRating, setServiceRating] = useState<number>(5);
  const [feedbackComment, setFeedbackComment] = useState("");
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false);

  // Device recognition
  const [deviceId] = useState(() => {
    let id = safeLocalStorage.getItem('customer_device_id');
    if (!id) {
      id = 'dev_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
      safeLocalStorage.setItem('customer_device_id', id);
    }
    return id;
  });

  // Load Categories, Menu Items, and configurations
  useEffect(() => {
    const unsubConfig = onSnapshot(doc(db, "settings", "config"), (docSnap) => {
      const defaultAreasList = [
        { id: "karrada", name: "الكرادة", fee: 2000 },
        { id: "jadriyah", name: "الجادرية", fee: 3000 },
        { id: "mansour", name: "المنصور", fee: 4000 },
        { id: "harthiya", name: "الحارثية", fee: 4000 },
        { id: "adhamiya", name: "الأعظمية", fee: 5000 },
        { id: "shaab", name: "الشعب", fee: 5000 },
        { id: "saydiya", name: "السيدية", fee: 5000 },
        { id: "yarmouk", name: "اليرموك", fee: 4000 },
        { id: "palestine", name: "شارع فلسطين", fee: 4000 },
        { id: "jamia", name: "حي الجامعة", fee: 5000 },
        { id: "ghazaliya", name: "الغزالية", fee: 6000 },
        { id: "dora", name: "الدورة", fee: 5000 },
        { id: "other", name: "منطقة أخرى / خارج حدود التغطية", fee: 7000 }
      ];

      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.restaurantName) setRestaurantName(data.restaurantName);
        if (data.deliveryDrivers) {
          const raw = data.deliveryDrivers || [];
          const normalized = raw.map((d: any) => typeof d === 'string' ? { name: d, phone: "" } : d);
          setDrivers(normalized);
        }
        const rawAreas = data.deliveryAreas || [];
        setDeliveryAreas(rawAreas.length > 0 ? rawAreas : defaultAreasList);
      } else {
        setDeliveryAreas(defaultAreasList);
      }
    });

    const unsubCats = onSnapshot(collection(db, "categories"), (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() } as Category));
      setCategories(list);
    });

    const unsubItems = onSnapshot(collection(db, "menuItems"), (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() } as MenuItem));
      setMenuItems(list);
    });

    return () => {
      unsubConfig();
      unsubCats();
      unsubItems();
    };
  }, []);

  // Listen to active order tracking document changes
  useEffect(() => {
    let unsubOrder = () => {};
    if (activeTrackingId) {
      setIsTrackingLoading(true);
      unsubOrder = onSnapshot(doc(db, "orders", activeTrackingId), (docSnap) => {
        if (docSnap.exists()) {
          setTrackedOrder({ id: docSnap.id, ...docSnap.data() } as OrderRecord);
        } else {
          // If deleted or not found, clear it
          setTrackedOrder(null);
          safeLocalStorage.removeItem('last_order_id');
          setActiveTrackingId(null);
        }
        setIsTrackingLoading(false);
      }, (err) => {
        console.error("Error loading tracked order:", err);
        setIsTrackingLoading(false);
      });
    } else {
      setTrackedOrder(null);
      setIsTrackingLoading(false);
    }
    return () => unsubOrder();
  }, [activeTrackingId]);

  // Subscribe to all previous orders from this device
  useEffect(() => {
    const q = query(
      collection(db, "orders"),
      where("metadata.deviceId", "==", deviceId)
    );
    const unsubHistory = onSnapshot(q, (snapshot) => {
      const ords = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as OrderRecord));
      // Sort desc by timestamp
      ords.sort((a, b) => {
        const tA = typeof a.timestamp === "number" ? a.timestamp : (a.timestamp?.seconds ? a.timestamp.seconds * 1000 : 0);
        const tB = typeof b.timestamp === "number" ? b.timestamp : (b.timestamp?.seconds ? b.timestamp.seconds * 1000 : 0);
        return tB - tA;
      });
      setPreviousOrders(ords);
    }, (err) => {
      console.error("Error subscribing to history:", err);
    });
    return () => unsubHistory();
  }, [deviceId]);

  // Autofill forms on first loads
  const hasAutofilledRef = useRef(false);
  useEffect(() => {
    if (previousOrders.length > 0 && !hasAutofilledRef.current) {
      const lastOrder = previousOrders[0];
      if (lastOrder.details) {
        setCustomerName(lastOrder.details.customerName || "");
        setCustomerPhone(lastOrder.details.customerPhone || "");
        setCustomerAddress(lastOrder.details.customerAddress || "");
        hasAutofilledRef.current = true;
      }
    }
  }, [previousOrders]);

  // Order countdown translation to Live Stepper Dashboard
  useEffect(() => {
    let interval: any = null;
    let redirectTimeout: any = null;

    if (isOrdered && lastPlacedOrder) {
      setCountdownSeconds(5);
      
      interval = setInterval(() => {
        setCountdownSeconds(prev => Math.max(0, prev - 1));
      }, 1000);

      redirectTimeout = setTimeout(() => {
        const ordId = lastPlacedOrder?.id;
        if (ordId) {
          setActiveTrackingId(ordId);
          safeLocalStorage.setItem('last_order_id', ordId);
        }
        safeLocalStorage.removeItem('last_placed_order');
        setLastPlacedOrder(null);
        setIsOrdered(false);
      }, 5000);
    }

    return () => {
      if (interval) clearInterval(interval);
      if (redirectTimeout) clearTimeout(redirectTimeout);
    };
  }, [isOrdered, lastPlacedOrder]);

  // Get active driver phone details
  const activeDriverInfo = useMemo(() => {
    if (!trackedOrder?.deliveryDriver) return null;
    const name = trackedOrder.deliveryDriver;
    const driverMatch = drivers.find(d => d.name === name);
    return driverMatch || { name, phone: "" };
  }, [trackedOrder, drivers]);

  // Filter food items
  const filteredItems = useMemo(() => {
    let list = menuItems;
    if (selectedCategory !== "all") {
      list = list.filter(item => item.category === selectedCategory);
    }
    if (searchQuery.trim() !== "") {
      const q = searchQuery.toLowerCase();
      list = list.filter(item => 
        item.name.toLowerCase().includes(q) || 
        (item.description && item.description.toLowerCase().includes(q))
      );
    }
    return list;
  }, [menuItems, selectedCategory, searchQuery]);

  // Cart operations
  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(i => i.quantity > 0));
  };

  const clearCart = () => setCart([]);

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [cart]);

  // Get GPS Coordinates
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert("الجهاز الحالي لا يدعم ميزة تحديد الموقع الجغرافي");
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const mapsLink = `https://www.google.com/maps?q=${latitude},${longitude}`;
        setCustomerAddress((prev) => {
          const base = prev.replace(/📍 الموقع الجغرافي: .*/gi, "").trim();
          return base 
            ? `${base}\n📍 الموقع الجغرافي: ${mapsLink}`
            : `📍 الموقع الجغرافي: ${mapsLink}`;
        });
        setIsLocating(false);
      },
      (err) => {
        console.error("GPS Error:", err);
        alert("فشل الحصول على الموقع الجغرافي. يرجى إدخال العنوان يدوياً.");
        setIsLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Submit order to Firestore
  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim()) {
      setSubmitError("يرجى ملء جميع الحقول الإلزامية لخدمة التوصيل");
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);

    try {
      // Map items with safety checks so we never send undefined fields
      const cleanedItems = cart.map(item => {
        const cleaned: any = {
          id: item.id || "",
          name: item.name || "",
          price: Number(item.price) || 0,
          category: item.category || "",
          quantity: Number(item.quantity) || 1
        };
        if (item.description) cleaned.description = item.description;
        return cleaned;
      });

      const ordersColRef = collection(db, "orders");
      const docRef = doc(ordersColRef);
      const orderId = docRef.id;

      // Fetch the latest order's secret code to compute the next sequential code
      let sequentialCode = "1001";
      try {
        const latestQuery = query(
          collection(db, "orders"),
          orderBy("timestamp", "desc"),
          limit(1)
        );
        const latestSnap = await getDocs(latestQuery);
        if (!latestSnap.empty) {
          const lastOrder = latestSnap.docs[0].data();
          const lastCode = lastOrder.secretCode;
          const parsed = parseInt(lastCode, 10);
          if (!isNaN(parsed)) {
            sequentialCode = (parsed + 1).toString();
          }
        }
      } catch (err) {
        console.error("Error creating sequential code:", err);
        sequentialCode = Math.floor(1000 + Math.random() * 9000).toString();
      }

      const orderData = {
        items: cleanedItems,
        total: Number(cartTotal),
        timestamp: Date.now(),
        createdBy: "المنيو الإلكتروني",
        shift: "أونلاين",
        orderType: "توصيل",
        status: 'pending',
        secretCode: sequentialCode,
        details: {
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim(),
          customerAddress: customerAddress.trim(),
          orderNotes: orderNotes.trim(),
          deliveryFee: 0 
        },
        metadata: {
          deviceId: deviceId || "",
          source: 'online_menu',
          createdAt: Date.now()
        }
      };

      // 1. Instantly store locally to avoid transition delays or sudden status blanks
      safeLocalStorage.setItem('last_order_id', orderId);
      const finalOrder = { id: orderId, ...orderData };
      safeLocalStorage.setItem('last_placed_order', JSON.stringify(finalOrder));

      // 2. Clear state and trigger screen
      setLastPlacedOrder(finalOrder);
      setIsOrdered(true);
      setCart([]);
      setIsCartOpen(false);

      // 3. Complete Firestore upload asynchronously
      setDoc(docRef, orderData)
        .then(() => console.log("Order submitted asynchronously:", orderId))
        .catch(err => console.error("Async Order write failed:", err));

    } catch (err: any) {
      console.error("Submit order failure:", err);
      setSubmitError("فشل في إرسال طلبك. يرجى المحاولة مرة أخرى.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Track older order via manual phone search
  const handlePhoneSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackPhoneInput.trim()) return;

    setIsTrackSearchLoading(true);
    setTrackPhoneError("");
    try {
      const q = query(
        collection(db, "orders"), 
        where("details.customerPhone", "==", trackPhoneInput.trim()),
        orderBy("timestamp", "desc"),
        limit(1)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        const foundId = snap.docs[0].id;
        safeLocalStorage.setItem('last_order_id', foundId);
        setActiveTrackingId(foundId);
        setShowTrackSearch(false);
      } else {
        setTrackPhoneError("عذراً، لم نجد أي طلبات نشطة بهذا الرقم");
      }
    } catch (err) {
      console.error(err);
      setTrackPhoneError("حدث خطأ أثناء البحث، يرجى المحاولة مجدداً");
    } finally {
      setIsTrackSearchLoading(false);
    }
  };

  // Submit Feedback / QA
  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingFeedback(true);
    try {
      await addDoc(collection(db, "feedbacks"), {
        platformRating,
        tasteRating,
        serviceRating,
        comment: feedbackComment.trim(),
        customerName: customerName.trim() || "زبون أونلاين",
        customerPhone: customerPhone.trim() || undefined,
        timestamp: Date.now(),
        orderId: activeTrackingId || ""
      });
      setFeedbackSubmitted(true);
      setFeedbackComment("");
    } catch (err) {
      console.error("Feedback submit error:", err);
    } finally {
      setIsSubmittingFeedback(false);
    }
  };

  // Map category ID to its visual icon (emoji or decorative label)
  const getCategoryIcon = (cat: Category) => {
    // Return emoji parsed if is one, or a fallback delicious icon
    return cat.icon || "🍔";
  };

  return (
    <div className="min-h-screen bg-zinc-50 font-sans antialiased text-zinc-900 pb-24" dir="rtl">
      
      {/* GLOBAL BACKGROUND DESIGN DECORATIONS */}
      <div className="absolute top-0 inset-x-0 h-48 bg-gradient-to-b from-orange-100/50 via-zinc-50/20 to-transparent pointer-events-none" />

      {/* HEADER SECTION */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-zinc-200/80 px-4 py-4 sm:px-6 shadow-sm">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-orange-500 to-amber-400 p-0.5 shadow-md shadow-orange-500/10 flex items-center justify-center">
              <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center font-black text-orange-600 text-lg">
                ج
              </div>
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-black tracking-tight text-zinc-900">{restaurantName}</h1>
              <span className="text-[10px] font-extrabold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full inline-block mt-0.5">
                • مفتوح الآن وجاهز للتوصيل 🛵
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Order History Trigger Button */}
            {previousOrders.length > 0 && (
              <button 
                onClick={() => setShowHistoryModal(true)}
                className="p-2 sm:px-4 sm:py-2 rounded-2xl bg-zinc-100 hover:bg-zinc-200/80 transition-all text-zinc-700 flex items-center gap-1.5 text-xs font-black shadow-sm"
              >
                <History className="w-4 h-4 text-zinc-550" />
                <span className="hidden sm:inline">طلباتي السابقة</span>
                <span className="bg-orange-500 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black">
                  {previousOrders.length}
                </span>
              </button>
            )}

            {/* Quick Tracking Status Finder */}
            {activeTrackingId ? (
              <button 
                onClick={() => setActiveTrackingId(activeTrackingId)}
                className="p-2 sm:px-4 sm:py-2 rounded-2xl bg-orange-50 text-orange-600 hover:bg-orange-100/80 transition-all flex items-center gap-1.5 text-xs font-black"
                id="active_tracking_ref_btn"
              >
                <Clock className="w-4 h-4 animate-spin text-orange-500" />
                <span>تتبع الطلب الحالي</span>
              </button>
            ) : (
              <button 
                onClick={() => setShowTrackSearch(true)}
                className="p-2 sm:px-4 sm:py-2 rounded-2xl bg-zinc-100 hover:bg-zinc-200 transition-all text-zinc-700 font-extrabold text-xs flex items-center gap-1"
              >
                <Search className="w-3.5 h-3.5" />
                <span>ابحث عن طلب</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* RENDER ACTIVE STEPS IN THE FLOW */}
      <main className="max-w-4xl mx-auto px-4 py-6 sm:py-8">
        
        {/* VIEW 1: Countdown screen for freshly submitted order */}
        {isOrdered && lastPlacedOrder ? (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[2.5rem] p-6 sm:p-10 border border-zinc-200 shadow-2xl relative overflow-hidden"
          >
            {/* Background design pattern */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-orange-100/30 rounded-bl-[100px] pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-emerald-100/20 rounded-tr-[100px] pointer-events-none" />

            <div className="text-center flex flex-col items-center">
              {/* Checkmark icon with ring ripple animation */}
              <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mb-6 relative">
                <span className="absolute inset-0 rounded-full bg-emerald-150 animate-ping opacity-20" />
                <Check className="w-10 h-10" strokeWidth={3} />
              </div>

              <span className="bg-emerald-500/10 text-emerald-700 px-4 py-1.5 rounded-full font-black text-xs uppercase tracking-wide mb-3 block">
                مبارك! تم إرسال طلبك بنجاح
              </span>
              <h2 className="text-2xl font-black text-zinc-900 tracking-tight leading-snug">سنأخذك الآن لتتبع حالة طعامك مباشرة</h2>
              <p className="text-zinc-550 text-xs sm:text-sm font-bold max-w-md mt-2 leading-relaxed">
                يتم إرسال طعامك اللذيذ مباشرة للمطبخ وكابتن التوطيد. لا داعي للتحديث، سننقلك تلقائياً خلال ثوانٍ.
              </p>

              {/* Countdown counter badge */}
              <div className="mt-8 flex flex-col items-center gap-4 w-full max-w-xs">
                <div className="text-3xl font-mono text-orange-600 font-black bg-orange-50 border border-orange-100 rounded-2xl px-5 py-2">
                  {countdownSeconds} <span className="text-xs font-sans text-orange-500">ثوانٍ</span>
                </div>
                
                {/* Visual smooth progress indicator bar */}
                <div className="w-full h-1.5 bg-zinc-100 rounded-full overflow-hidden relative">
                  <motion.div 
                    initial={{ width: "100%" }}
                    animate={{ width: `${(countdownSeconds / 5) * 100}%` }}
                    transition={{ ease: "linear", duration: 1 }}
                    className="absolute right-0 top-0 bottom-0 bg-gradient-to-l from-orange-500 to-amber-500"
                  />
                </div>
              </div>

              {/* Simple manually skip triggers */}
              <div className="mt-8 pt-6 border-t border-zinc-100 w-full flex flex-col gap-2.5">
                <button 
                  onClick={() => {
                    const ordId = lastPlacedOrder?.id;
                    if (ordId) {
                      setActiveTrackingId(ordId);
                      safeLocalStorage.setItem('last_order_id', ordId);
                    }
                    safeLocalStorage.removeItem('last_placed_order');
                    setLastPlacedOrder(null);
                    setIsOrdered(false);
                  }}
                  className="w-full bg-zinc-950 text-white h-12 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-md hover:bg-black transition-all"
                >
                  تخطي الانتقال والذهاب للتتبع حالاً 🏁
                </button>
                <button 
                  onClick={() => {
                    safeLocalStorage.removeItem('last_placed_order');
                    setLastPlacedOrder(null);
                    setIsOrdered(false);
                  }}
                  className="w-full text-zinc-500 h-10 rounded-2xl text-xs font-bold hover:bg-zinc-100 transition-all"
                >
                  الرجوع لتصفح المنيو مجدداً
                </button>
              </div>
            </div>
          </motion.div>
        ) : activeTrackingId ? (
          
          /* VIEW 2: Order Live Tracker Dashboard */
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col gap-6"
          >
            {/* Top Back and Sync bar */}
            <div className="flex items-center justify-between">
              <button 
                onClick={() => {
                  setActiveTrackingId(null);
                  setTrackedOrder(null);
                }}
                className="flex items-center gap-1.5 text-zinc-650 hover:text-zinc-950 text-xs sm:text-sm font-black bg-white px-3 py-2 rounded-xl border border-zinc-200 transition-all select-none"
              >
                <ArrowLeft className="w-4 h-4 text-zinc-500" />
                <span>العودة للمنيو وتعديل الطلبات</span>
              </button>

              <div className="flex items-center gap-2">
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-orange-500"></span>
                </span>
                <span className="text-[11px] font-extrabold text-zinc-400 select-none">موصول ومحدث تلقائياً</span>
              </div>
            </div>

            {/* If Order doc loader is working */}
            {isTrackingLoading && !trackedOrder ? (
              <div className="bg-white rounded-[2rem] p-12 border border-zinc-150 shadow-md text-center flex flex-col items-center justify-center min-h-[300px]">
                <Loader2 size={32} className="animate-spin text-orange-500 mb-4" />
                <p className="text-zinc-550 text-sm font-extrabold">جاري الاتصال بخادم المطعم لبث التحديثات...</p>
              </div>
            ) : !trackedOrder ? (
              <div className="bg-white rounded-[2rem] p-12 border border-zinc-150 shadow-md text-center flex flex-col items-center justify-center min-h-[300px]">
                <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 mb-4 font-black text-lg">!</div>
                <h3 className="text-lg font-black text-zinc-900">عذراً، لم نتمكن من العثور على تفاصيل هذا الطلب</h3>
                <p className="text-zinc-450 text-xs font-bold mt-2 max-w-xs leading-relaxed">ربما تم حذف الطلب من قبل الإدارة أو انتهت فترة صلاحيته المؤقتة.</p>
                <button 
                  onClick={() => {
                    setActiveTrackingId(null);
                    safeLocalStorage.removeItem('last_order_id');
                  }}
                  className="mt-6 bg-zinc-950 text-white text-xs px-6 py-2.5 rounded-xl font-black shadow"
                >
                  العودة لتصفح المنيو
                </button>
              </div>
            ) : (
              
              /* STUNNING ACTIVE TRACKING PANEL */
              <div className="flex flex-col gap-6">
                
                {/* 1. Header Card detailing visual status and summary */}
                <div className="bg-white rounded-[2.5rem] p-6 sm:p-8 border border-zinc-200 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative overflow-hidden">
                  {/* Backdrop splash */}
                  <div className="absolute left-0 top-0 bottom-0 w-2 bg-orange-500 pointer-events-none" />
                  
                  <div className="flex flex-col gap-2 relative">
                    <div className="flex items-center gap-2">
                      <span className="bg-orange-50 text-orange-600 border border-orange-150 px-2.5 py-0.5 rounded-lg text-[10px] font-black tracking-widest uppercase">
                        رقم كود الطلب: {trackedOrder.secretCode}
                      </span>
                    </div>
                    <h2 className="text-xl font-black text-zinc-900 mt-1">
                      أهلاً، {trackedOrder.details?.customerName || "يا زبوننا العزيز"} 👋
                    </h2>
                    <p className="text-zinc-500 text-xs font-bold flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-zinc-400" />
                      <span>وقت الطلب: </span>
                      <span className="font-mono text-zinc-700">
                        {(() => {
                          const t = trackedOrder.timestamp;
                          if (!t) return "الآن";
                          const d = typeof t === 'number' ? new Date(t) : (t.seconds ? new Date(t.seconds * 1000) : new Date());
                          return d.toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }) + " - " + d.toLocaleDateString('ar-IQ', { month: 'short', day: 'numeric' });
                        })()}
                      </span>
                    </p>
                  </div>

                  <div className="bg-zinc-50 rounded-2xl p-4 border border-zinc-150 flex flex-col gap-1 items-end min-w-[130px] self-start sm:self-auto text-right">
                    <span className="text-[10px] text-zinc-400 font-extrabold">إجمالي الحساب المالي</span>
                    <span className="text-xl font-mono font-black text-emerald-600 block pt-0.5">
                      {trackedOrder.total.toLocaleString()} د.ع
                    </span>
                    <span className="text-[10px] font-bold text-zinc-400 bg-zinc-200/50 px-1.5 py-0.5 rounded">
                      نقدي عند الاستلام 💵
                    </span>
                  </div>
                </div>

                {/* 2. Seamless STEP-BY-STEP Stepper */}
                <div className="bg-white rounded-[2.5rem] p-6 sm:p-8 border border-zinc-200 shadow-xl">
                  <h3 className="text-base font-black text-zinc-900 mb-6 flex items-center gap-2 border-b border-zinc-100 pb-4">
                    <Utensils className="w-5 h-5 text-orange-500" />
                    <span>مراحل تجهيز وتوصيل وجبتك بالثواني</span>
                  </h3>

                  {/* Vertically Styled Timeline Connected to DB */}
                  <div className="flex flex-col gap-6 relative pr-8">
                    {/* Vertical Connecting line backend helper */}
                    <div className="absolute right-3.5 top-3.5 bottom-3.5 w-0.5 bg-zinc-200 pointer-events-none" />

                    {/* Stepper Step 1: Pending (استلام الطلب) */}
                    {(() => {
                      const isActive = true; // Always active if order exists
                      const isDone = trackedOrder.status !== 'pending';
                      return (
                        <div className="flex items-start gap-4 relative">
                          <div className={`absolute right-[-24px] top-1.5 w-7 h-7 rounded-full flex items-center justify-center text-white z-10 transition-all ${
                            isDone ? 'bg-emerald-500 shadow-md shadow-emerald-500/20' : 'bg-orange-500 animate-pulse ring-4 ring-orange-100'
                          }`}>
                            {isDone ? <Check className="w-3.5 h-3.5" strokeWidth={3} /> : <span className="text-[10px] font-black">1</span>}
                          </div>
                          <div className={`flex-1 rounded-2xl p-4 transition-all ${
                            !isDone ? 'bg-orange-50/50 border border-orange-100' : 'bg-white border border-transparent'
                          }`}>
                            <h4 className="text-sm font-black text-zinc-900 flex items-center gap-1.5">
                              <span>لقد استقبلنا طلبك بنجاح</span>
                              {!isDone && <span className="text-[10px] text-orange-600 bg-orange-100/60 px-2 py-0.5 rounded-md font-bold">بانتظار التأكيد</span>}
                            </h4>
                            <p className="text-zinc-500 text-xs font-medium mt-1 leading-relaxed">
                              تم التبليغ وبث الفاتورة للوحة التحكم الرئيسية للمطعم، وجاري توجيه كباتن المطبخ للتحضير.
                            </p>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Stepper Step 2: Preparing (المطبخ يحضر) */}
                    {(() => {
                      const isActive = trackedOrder.status !== 'pending';
                      const isDone = trackedOrder.status === 'on_way' || trackedOrder.status === 'delivered';
                      const isCurrentlyActive = trackedOrder.status === 'preparing';
                      return (
                        <div className="flex items-start gap-4 relative">
                          <div className={`absolute right-[-24px] top-1.5 w-7 h-7 rounded-full flex items-center justify-center text-white z-10 transition-all ${
                            isDone ? 'bg-emerald-500 shadow-md' : (isCurrentlyActive ? 'bg-orange-500 animate-pulse ring-4 ring-orange-100' : 'bg-zinc-200 text-zinc-400')
                          }`}>
                            {isDone ? <Check className="w-3.5 h-3.5" strokeWidth={3} /> : <span className="text-[10px] font-black">2</span>}
                          </div>
                          <div className={`flex-1 rounded-2xl p-4 transition-all ${
                            isCurrentlyActive ? 'bg-orange-50/50 border border-orange-100' : 'bg-white border border-transparent'
                          } ${!isActive ? 'opacity-50' : ''}`}>
                            <h4 className="text-sm font-black text-zinc-900 flex items-center gap-1.5">
                              <span>المطبخ يقوم بتحضير طعامك اللذيذ الآن</span>
                              {isCurrentlyActive && (
                                <span className="text-[10px] text-orange-600 bg-orange-100/60 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                                  <Loader2 size={10} className="animate-spin" />
                                  <span>قيد الطهي</span>
                                </span>
                              )}
                            </h4>
                            <p className="text-zinc-500 text-xs font-medium mt-1 leading-relaxed">
                              يقوم طهاة المعجنات واللحوم بتجهيز المكونات الطازجة وطهيها بعناية لضمان الطعم الخرافي الحار.
                            </p>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Stepper Step 3: On Way (توصيل الكابتن) */}
                    {(() => {
                      const isActive = trackedOrder.status === 'on_way' || trackedOrder.status === 'delivered';
                      const isDone = trackedOrder.status === 'delivered';
                      const isCurrentlyActive = trackedOrder.status === 'on_way';
                      return (
                        <div className="flex items-start gap-4 relative">
                          <div className={`absolute right-[-24px] top-1.5 w-7 h-7 rounded-full flex items-center justify-center text-white z-10 transition-all ${
                            isDone ? 'bg-emerald-500 shadow-md' : (isCurrentlyActive ? 'bg-orange-500 animate-pulse ring-4 ring-orange-100' : 'bg-zinc-200 text-zinc-400')
                          }`}>
                            {isDone ? <Check className="w-3.5 h-3.5" strokeWidth={3} /> : <span className="text-[10px] font-black">3</span>}
                          </div>
                          <div className={`flex-1 rounded-2xl p-4 transition-all ${
                            isCurrentlyActive ? 'bg-orange-50/50 border border-orange-100' : 'bg-white border border-transparent'
                          } ${!isActive ? 'opacity-50' : ''}`}>
                            <h4 className="text-sm font-black text-zinc-900 flex items-center gap-1.5">
                              <span>مع كابتن التوصيل في الطريق إليك</span>
                              {isCurrentlyActive && (
                                <span className="text-[10px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                                  <span>منطلق الآن 🚴</span>
                                </span>
                              )}
                            </h4>
                            <p className="text-zinc-500 text-xs font-medium mt-1 leading-relaxed">
                              تم تغليف الطعام حرارياً وتسليمه للكابتن المسؤول لينطلق إليك في أسرع وقت.
                            </p>

                            {/* Driver detail container if on_way */}
                            {isActive && activeDriverInfo && (
                              <div className="mt-3 bg-zinc-50 border border-zinc-150 rounded-xl p-3 flex items-center justify-between gap-3">
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center text-orange-600 font-black text-xs">
                                    🚴
                                  </div>
                                  <div>
                                    <p className="text-xs font-black text-zinc-900 leading-none">{activeDriverInfo.name}</p>
                                    <span className="text-[9px] text-zinc-400 font-bold block mt-1">المكلف بالتصميم والتوصيل</span>
                                  </div>
                                </div>

                                {activeDriverInfo.phone && (
                                  <a 
                                    href={`tel:${activeDriverInfo.phone}`}
                                    className="px-3 py-1.5 bg-emerald-50 text-emerald-600 border border-emerald-150 rounded-lg text-[10px] font-extrabold flex items-center gap-1.5 shadow-sm active:scale-95 hover:bg-emerald-500 hover:text-white transition-all select-none"
                                  >
                                    <PhoneCall className="w-3.5 h-3.5" />
                                    <span>اتصل بالكابتن</span>
                                  </a>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })()}

                    {/* Stepper Step 4: Delivered (تم الاستلام بالعافية) */}
                    {(() => {
                      const isActive = trackedOrder.status === 'delivered';
                      return (
                        <div className="flex items-start gap-4 relative">
                          <div className={`absolute right-[-24px] top-1.5 w-7 h-7 rounded-full flex items-center justify-center text-white z-10 transition-all ${
                            isActive ? 'bg-emerald-500 shadow-md ring-4 ring-emerald-100' : 'bg-zinc-200 text-zinc-400'
                          }`}>
                            <CheckCircle2 className="w-4 h-4" />
                          </div>
                          <div className={`flex-1 rounded-2xl p-4 transition-all ${
                            isActive ? 'bg-emerald-50/50 border border-emerald-100' : 'bg-white border border-transparent'
                          } ${!isActive ? 'opacity-50' : ''}`}>
                            <h4 className="text-sm font-black text-zinc-900">
                              <span>تم تسليم وجبتك بنجاح! بالعافية</span>
                            </h4>
                            <p className="text-zinc-500 text-xs font-medium mt-1 leading-relaxed">
                              شكراً لاختيارك وجباتنا. نتمنى لك وجبة شهية ويوم سعيد.
                            </p>
                          </div>
                        </div>
                      );
                    })()}

                  </div>
                </div>

                {/* 3. Items Summary inside the Tracked Order */}
                <div className="bg-white rounded-[2.5rem] p-6 sm:p-8 border border-zinc-200 shadow-xl">
                  <h3 className="text-sm font-black text-zinc-400 select-none pb-3 border-b border-zinc-100 mb-4">
                    محتويات هذا الطلب بالتفصيل
                  </h3>
                  
                  <div className="flex flex-col gap-3">
                    {(trackedOrder.items || []).map((i, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs sm:text-sm text-right">
                        <div className="flex items-center gap-2">
                          <span className="font-mono bg-zinc-100 text-zinc-700 w-6 h-6 rounded-md flex items-center justify-center font-bold">
                            {i.quantity}x
                          </span>
                          <span className="font-extrabold text-zinc-850">{i.name}</span>
                        </div>
                        <span className="font-mono font-bold text-zinc-500">
                          {((i.price || 0) * (i.quantity || 1)).toLocaleString()} د.ع
                        </span>
                      </div>
                    ))}

                    <div className="pt-4 border-t border-zinc-100 flex justify-between items-center font-black mt-2">
                      <span className="text-zinc-600 text-xs sm:text-sm">إجمالي الوجبات مع التوصيل المجاني</span>
                      <span className="text-[17px] text-zinc-900 font-mono font-black">
                        {trackedOrder.total.toLocaleString()} د.ع
                      </span>
                    </div>

                    {trackedOrder.details?.orderNotes && (
                      <div className="bg-zinc-50 border border-zinc-150 text-zinc-600 p-3 rounded-xl text-xs font-bold leading-normal mt-3">
                        💡 ملاحظاتك: {trackedOrder.details.orderNotes}
                      </div>
                    )}
                  </div>
                </div>

              </div>
            )}
          </motion.div>
        ) : (
          
          /* VIEW 3: Main Food Interactive Menu */
          <div className="flex flex-col gap-6">
            
            {/* 1. Header Hero Panel with Restaurant Greeting & Search */}
            <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 rounded-[2.5rem] p-6 sm:p-8 text-white relative shadow-xl overflow-hidden mb-2">
              {/* Backdrops */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex justify-between items-start gap-4 mb-4">
                <div className="relative z-10">
                  <span className="text-orange-400 text-xs font-black inline-flex items-center gap-1.5 mb-1 bg-white/10 px-3 py-1 rounded-full uppercase tracking-wider">
                    <Sparkles className="w-3 h-3" />
                     أفضل الوجبات بانتظارك
                  </span>
                  <h2 className="text-xl sm:text-2xl font-black text-white/95 mt-1">تصفح وجباتك اللذيذة واطلب في ثوانٍ</h2>
                  <p className="text-zinc-400 text-xs font-bold leading-normal mt-1.5 max-w-sm sm:max-w-md">
                    نحن نحضر طعامك بمكونات طازجة 100% ويتم التوصيل الحار مباشرة لباب منزلك مع كابتن التوصيل.
                  </p>
                </div>
              </div>

              {/* Dynamic Culinary Search component */}
              <div className="relative mt-6 z-10">
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="تبحث عن بركر، شيش، معجنات، أو مقبلات محددة؟ اكتب هنا..."
                  className="w-full bg-white/10 focus:bg-white text-zinc-900 placeholder:text-zinc-400 focus:placeholder:text-zinc-550 border border-white/10 focus:border-orange-500 outline-none rounded-2xl py-3.5 pr-12 pl-4 text-xs sm:text-sm font-bold transition-all shadow-inner"
                />
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 font-black" size={18} />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery("")}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-lg bg-zinc-200/50 hover:bg-zinc-200 text-zinc-700 flex items-center justify-center transition-all focus:outline-none"
                  >
                    <X size={12} strokeWidth={3} />
                  </button>
                )}
              </div>
            </div>

            {/* 2. Horizontal Categories Horizontal Quick Bar */}
            <div className="flex flex-col gap-3">
              <h3 className="text-xs font-extrabold tracking-wide text-zinc-400 select-none px-1">تصنيفات الوجبات المتاحة</h3>
              
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none snap-x snap-mandatory pr-1">
                {/* 'All' category card toggle */}
                <button
                  onClick={() => setSelectedCategory("all")}
                  className={`px-4 py-3 rounded-2xl flex items-center gap-2 select-none shrink-0 border transition-all snap-start cursor-pointer ${
                    selectedCategory === "all"
                      ? 'bg-gradient-to-l from-orange-600 to-orange-500 text-white border-orange-500 shadow-md shadow-orange-500/10'
                      : 'bg-white text-zinc-700 border-zinc-200/75 hover:bg-zinc-50'
                  }`}
                >
                  <span className="text-sm">🔥</span>
                  <span className="text-xs font-black">كل الوجبات</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                    selectedCategory === 'all' ? 'bg-orange-700 text-white' : 'bg-zinc-100 text-zinc-500'
                  }`}>
                    {menuItems.length}
                  </span>
                </button>

                {categories.map((cat) => {
                  const itemsInCat = menuItems.filter(item => item.category === cat.id);
                  const isSel = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-4 py-3 rounded-2xl flex items-center gap-2 select-none shrink-0 border transition-all snap-start cursor-pointer ${
                        isSel
                          ? 'bg-gradient-to-l from-orange-600 to-orange-500 text-white border-orange-500 shadow-md shadow-orange-500/10'
                          : 'bg-white text-zinc-700 border-zinc-200/75 hover:bg-zinc-50'
                      }`}
                    >
                      <span className="text-sm">{getCategoryIcon(cat)}</span>
                      <span className="text-xs font-black">{cat.name}</span>
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                        isSel ? 'bg-orange-700 text-white' : 'bg-zinc-100 text-zinc-500'
                      }`}>
                        {itemsInCat.length}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Render Food Items Grid */}
            <div className="mt-2">
              {filteredItems.length === 0 ? (
                <div className="bg-white rounded-[2rem] border border-zinc-200/75 p-12 text-center flex flex-col items-center justify-center">
                  <div className="w-12 h-12 bg-zinc-100 rounded-full flex items-center justify-center font-black text-zinc-400 mb-3 text-lg">❔</div>
                  <h4 className="text-sm font-black text-zinc-800">عذراً، لم نجد أي وجبات متطابقة</h4>
                  <p className="text-zinc-400 text-xs font-bold leading-normal mt-1">حاول البحث باستخدام كلمة أخرى، أو غير تصنيف المأكولات المحدد.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredItems.map((item) => {
                    const countInCart = cart.find(i => i.id === item.id)?.quantity || 0;
                    const isAvailable = item.available !== false;
                    return (
                      <motion.div 
                        layout="position"
                        key={item.id}
                        className={`bg-white rounded-3xl p-4 border border-zinc-200/75 hover:border-orange-500/50 transition-all flex flex-col justify-between gap-4 relative overflow-hidden group hover:shadow-lg ${
                          !isAvailable ? 'opacity-60 bg-zinc-50/50' : ''
                        }`}
                      >
                        <div className="flex justify-between items-start gap-3">
                          <div className="flex-1 text-right">
                            <span className="text-[10px] font-extrabold text-zinc-400 uppercase bg-zinc-100 px-2 py-0.5 rounded mb-1.5 inline-block">
                              {categories.find(c => c.id === item.category)?.name || "وجبات أساسية"}
                            </span>
                            <h4 className="text-sm font-black text-zinc-900 group-hover:text-orange-600 transition-colors leading-snug">
                              {item.name}
                            </h4>
                            {item.description && (
                              <p className="text-zinc-450 text-[11px] font-bold leading-relaxed mt-1 text-zinc-500 max-h-12 overflow-hidden text-ellipsis line-clamp-2">
                                {item.description}
                              </p>
                            )}
                          </div>

                          <div className="text-left font-mono shrink-0">
                            <span className="text-xs font-black text-orange-600 bg-orange-50 px-2.5 py-1 rounded-xl block">
                              {item.price.toLocaleString()} د.ع
                            </span>
                          </div>
                        </div>

                        {/* Order action triggers */}
                        <div className="flex justify-between items-center pt-2 border-t border-zinc-100 mt-1 select-none">
                          <div className="text-xs">
                            {!isAvailable && (
                              <span className="text-[11px] font-black text-red-600 bg-red-50 border border-red-100 px-2.5 py-1 rounded-lg">
                                غير متوفر حالياً 🚫
                              </span>
                            )}
                          </div>

                          {isAvailable && (
                            <div className="flex items-center gap-1.5 self-end">
                              {countInCart > 0 ? (
                                <div className="flex items-center gap-2 bg-gradient-to-l from-zinc-950 to-zinc-900 text-white rounded-xl p-1 shrink-0">
                                  <button 
                                    onClick={() => updateQuantity(item.id, -1)}
                                    className="w-7 h-7 bg-white/10 hover:bg-white/20 active:scale-90 rounded-lg flex items-center justify-center font-black transition-all cursor-pointer"
                                  >
                                    <Minus size={12} strokeWidth={3} />
                                  </button>
                                  <span className="px-1 text-xs font-mono font-black min-w-[12px] text-center">
                                    {countInCart}
                                  </span>
                                  <button 
                                    onClick={() => addToCart(item)}
                                    className="w-7 h-7 bg-white/10 hover:bg-white/20 active:scale-90 rounded-lg flex items-center justify-center font-black transition-all cursor-pointer"
                                  >
                                    <Plus size={12} strokeWidth={3} />
                                  </button>
                                </div>
                              ) : (
                                <button 
                                  onClick={() => addToCart(item)}
                                  className="px-3.5 py-1.5 bg-orange-555 bg-orange-600 text-white hover:bg-orange-700 active:scale-95 text-xs font-black rounded-xl shadow-md shadow-orange-500/10 flex items-center gap-1 transition-all cursor-pointer"
                                >
                                  <Plus size={14} strokeWidth={2.5} />
                                  <span>أضف للوجبة</span>
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>
        )}

      </main>

      {/* FLOATING PRIMARY BASKET TRIGGER (STAYS AT THE BOTTOM ALWAYS IF BASKET HAS ITEMS) */}
      {cart.length > 0 && !isOrdered && (
        <div className="fixed bottom-6 inset-x-4 z-40 max-w-lg mx-auto select-none">
          <button 
            onClick={() => setIsCartOpen(true)}
            className="w-full bg-gradient-to-l from-orange-600 to-orange-500 text-white h-14 sm:h-16 rounded-[20px] px-4 flex items-center justify-between shadow-xl shadow-orange-600/20 active:scale-[0.98] transition-all cursor-pointer border border-orange-500/40 relative overflow-hidden group"
          >
            {/* Ambient sliding light glare effect */}
            <span className="absolute inset-x-0 top-0 bottom-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-in-out pointer-events-none" />

            <div className="flex items-center gap-3">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white/25 flex items-center justify-center text-white relative">
                <ShoppingBag size={18} strokeWidth={2.5} />
                <span className="absolute -top-1.5 -right-1.5 bg-zinc-950 text-white w-5 h-5 rounded-full text-[10px] font-black flex items-center justify-center border-2 border-orange-500">
                  {cart.length}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-black text-white/90 block">عرض محتويات السلة والطلب</span>
                <span className="text-[10px] text-orange-100 font-extrabold flex items-center gap-1 mt-0.5">
                  🛵 المطبخ مؤمن والتوصيل فوري
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 font-mono font-black text-sm pr-2 border-r border-white/20">
              <span>{cartTotal.toLocaleString()} د.ع</span>
              <ChevronLeft size={16} strokeWidth={2.5} />
            </div>
          </button>
        </div>
      )}

      {/* CART OVERLAY / SLIDE IN DRAWER CONTAINER */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden" dir="rtl">
            {/* Backdrop click-to-close */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-neutral-900/60 backdrop-blur-sm cursor-pointer"
            />

            {/* Slide up panel */}
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="absolute bottom-0 inset-x-0 bg-white rounded-t-[2.5rem] border-t border-zinc-200/90 max-h-[92vh] flex flex-col shadow-2xl overflow-hidden"
            >
              {/* Drawer handle visual decorator */}
              <div className="w-12 h-1 bg-zinc-200 rounded-full mx-auto mt-3 mb-1 shrink-0" />

              {/* Header block */}
              <div className="px-4 py-3 sm:px-6 flex items-center justify-between border-b border-zinc-100 shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                    🛒
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-zinc-900">سلة وجباتك اللذيذة</h3>
                    <span className="text-[10px] font-bold text-zinc-400">تراجع، زد الكميات، أو أضف تفاصيل التوصيل</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={clearCart}
                    className="text-[10px] bg-red-50 text-red-600 border border-red-100 hover:bg-red-100 hover:text-red-700 px-2.5 py-1.5 rounded-lg font-black transition-all select-none"
                  >
                    تفريغ السلة
                  </button>
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="p-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-600 rounded-full transition-all"
                  >
                    <X size={16} strokeWidth={2.5} />
                  </button>
                </div>
              </div>

              {/* Scrollable list & Checkout inputs wrapper */}
              <div className="flex-1 overflow-y-auto px-4 py-4 sm:px-6 space-y-6">
                
                {/* 1. Basket food items content */}
                <div className="space-y-3">
                  <h4 className="text-[11px] font-black text-zinc-400 select-none px-1">محتويات طعامك بالسلة</h4>
                  
                  {cart.map((item) => (
                    <div 
                      key={item.id} 
                      className="bg-zinc-50 border border-zinc-150 rounded-2xl p-3 sm:p-4 flex justify-between items-center gap-4 transition-all"
                    >
                      <div className="flex-1 min-w-0 pr-1 text-right">
                        <h4 className="text-xs sm:text-sm font-black text-zinc-900 leading-snug truncate">
                          {item.name}
                        </h4>
                        <span className="text-[10px] font-mono text-orange-600 bg-orange-50 border border-orange-100 px-1.5 py-0.5 rounded-md inline-block mt-1 font-black">
                          {item.price.toLocaleString()} د.ع
                        </span>
                      </div>

                      {/* Quantities changer */}
                      <div className="flex items-center gap-2 select-none shrink-0 bg-white border border-zinc-150 p-1 rounded-xl">
                        <button 
                          onClick={() => updateQuantity(item.id, -1)}
                          className="w-7 h-7 hover:bg-zinc-100 rounded-lg flex items-center justify-center text-zinc-650 font-black transition-all cursor-pointer"
                        >
                          <Minus size={11} strokeWidth={3} />
                        </button>
                        <span className="text-xs font-mono font-black min-w-[14px] text-center text-zinc-800">
                          {item.quantity}
                        </span>
                        <button 
                          onClick={() => addToCart(item)}
                          className="w-7 h-7 hover:bg-zinc-100 rounded-lg flex items-center justify-center text-zinc-650 font-black transition-all cursor-pointer"
                        >
                          <Plus size={11} strokeWidth={3} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 2. Customer delivery address checkout form */}
                <form id="online_checkout_form" onSubmit={handleSubmitOrder} className="space-y-4 pt-4 border-t border-zinc-100">
                  <h4 className="text-[11px] font-black text-zinc-400 select-none px-1">معلومات وعنوان التوصيل الفوري</h4>

                  {submitError && (
                    <div className="bg-red-50 border border-red-150 p-3 rounded-xl text-red-600 font-extrabold text-xs">
                      ⚠️ {submitError}
                    </div>
                  )}

                  {/* Customer Full Name */}
                  <div className="relative group">
                    <input 
                      required
                      type="text" 
                      placeholder="اسمك الكريم..." 
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-2xl px-11 py-3.5 text-xs sm:text-sm outline-none focus:border-orange-500 focus:bg-white transition-all text-right font-black focus:ring-4 focus:ring-orange-500/5 placeholder:text-zinc-400"
                    />
                    <User className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-orange-500 transition-colors" size={16} />
                  </div>

                  {/* Customer Phone Number */}
                  <div className="relative group">
                    <input 
                      required
                      type="tel" 
                      placeholder="رقم الهاتف الخلوي (لتسهيل تواصل الكابتن)..." 
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-2xl px-11 py-3.5 text-xs sm:text-sm outline-none focus:border-orange-500 focus:bg-white transition-all text-left font-mono font-black focus:ring-4 focus:ring-orange-500/5 placeholder:text-right placeholder:text-zinc-400"
                    />
                    <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-orange-500 transition-colors" size={16} />
                  </div>

                  {/* Address + GPS Button */}
                  <div className="relative group space-y-2">
                    <div className="flex justify-between items-center px-1">
                      <span className="text-[10px] font-black text-zinc-400 leading-none">تفاصيل العنوان الحالي للزبون (شارع، حي، أقرب دالة)</span>
                      
                      {/* GPS Button */}
                      <button 
                        type="button"
                        onClick={handleGetLocation}
                        disabled={isLocating}
                        className="text-[10px] bg-sky-50 text-sky-600 border border-sky-150 hover:bg-sky-500 hover:text-white px-2.5 py-1 rounded-full font-black flex items-center gap-1 shadow-sm transition-all disabled:opacity-50 active:scale-95 shrink-0 select-none cursor-pointer"
                      >
                        {isLocating ? <Loader2 size={10} className="animate-spin" /> : <Navigation size={10} strokeWidth={2.5} />}
                        <span>تحديد موقعي التلقائي (GPS) 📍</span>
                      </button>
                    </div>

                    <div className="relative">
                      <textarea 
                        required
                        rows={2}
                        placeholder="أدخل الشارع، الحي، الطابق، أو أقرب دالة لتفادي تأخر التوصيل..." 
                        value={customerAddress}
                        onChange={(e) => setCustomerAddress(e.target.value)}
                        className="w-full bg-zinc-50 border border-zinc-200 rounded-2xl px-11 py-3.5 text-xs sm:text-sm outline-none focus:border-orange-500 focus:bg-white transition-all text-right font-black focus:ring-4 focus:ring-orange-500/5 placeholder:text-zinc-400 resize-none"
                      />
                      <MapPin className="absolute right-4 top-4 text-zinc-400 group-focus-within:text-orange-500 transition-colors" size={16} />
                    </div>
                  </div>

                  {/* Preparations instructions notes */}
                  <div className="relative">
                    <span className="text-[10px] font-black text-zinc-400 px-1 block mb-1">ملاحظة خاصة للمطبخ أو الكابتن (اختياري)</span>
                    <input 
                      type="text" 
                      placeholder="مثال: بدون بصل، زيادة بيسي، اترك الطلب عند الباب..." 
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-2xl p-3 text-xs sm:text-sm outline-none focus:border-orange-500 focus:bg-white transition-all text-right font-black focus:ring-4 focus:ring-orange-500/5 placeholder:text-zinc-400"
                    />
                  </div>

                </form>

              </div>

              {/* Total price visual and final Checkout submit button */}
              <div className="p-4 sm:p-6 bg-zinc-100 border-t border-zinc-200 shrink-0 text-right">
                <div className="max-w-md mx-auto space-y-4">
                  
                  <div className="flex justify-between items-center text-xs text-zinc-600 font-black pb-1">
                    <span>🛵 طريقة الدفع والتوصيل:</span>
                    <span className="bg-emerald-500/10 text-emerald-700 px-3 py-1 rounded-full font-black text-[11px]">
                      توصيل فوري كاش عند الاستلام 🏍️
                    </span>
                  </div>

                  <div className="flex justify-between items-center font-black border-t border-zinc-200/60 pt-3 mt-1">
                    <span className="text-zinc-900 text-sm sm:text-base">الإجمالي المطلوب كاش</span>
                    <span className="text-2xl sm:text-3xl text-emerald-600 font-mono tracking-tight font-black">
                      {cartTotal.toLocaleString()} <span className="text-xs">د.ع</span>
                    </span>
                  </div>

                  <button 
                    form="online_checkout_form"
                    type="submit"
                    disabled={isSubmitting || cart.length === 0}
                    className="w-full h-14 bg-gradient-to-l from-orange-600 to-orange-500 text-white hover:from-orange-700 hover:to-orange-600 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-orange-600/10 transition-all select-none active:scale-[0.98] disabled:opacity-50 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        <span>جاري معالجة وجبتك بسلام...</span>
                      </>
                    ) : (
                      <>
                        <Truck size={16} strokeWidth={2.5} />
                        <span>إرسال وتجهيز الطلب الآن 🚀</span>
                      </>
                    )}
                  </button>

                  <p className="text-[10px] text-zinc-400 font-bold text-center">
                    بمجرد الضغط على إرسال، يبدأ الطاهي بالعمل لتجهيز طعامك الحار 🌶️
                  </p>
                </div>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MANUAL TRACKING PHONE SEARCH POPUP MODAL */}
      <AnimatePresence>
        {showTrackSearch && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4" dir="rtl">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowTrackSearch(false)}
              className="absolute inset-0 bg-neutral-900/60 backdrop-blur-sm cursor-pointer"
            />

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[2rem] p-6 max-w-sm w-full relative z-10 border border-zinc-200 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-black text-zinc-900 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-orange-500" />
                  <span>تتبع الطلبات المسجلة</span>
                </h3>
                <button 
                  onClick={() => setShowTrackSearch(false)}
                  className="p-1.5 bg-zinc-100 hover:bg-zinc-200 rounded-lg text-zinc-650 transition-all"
                >
                  <X size={14} strokeWidth={2.5} />
                </button>
              </div>

              <p className="text-zinc-550 text-xs font-bold leading-normal mb-4">
                أدخل رقم الهاتف الذي استخدمته عند إرسال الطلب، لعرض حالة التجهيز الكلي بالزمن الحقيقي.
              </p>

              {trackPhoneError && (
                <div className="bg-orange-50/70 border border-orange-150 p-3 rounded-xl text-orange-700 font-extrabold text-[11px] mb-3 text-right">
                  ⚠️ {trackPhoneError}
                </div>
              )}

              <form onSubmit={handlePhoneSearchSubmit} className="space-y-4">
                <div className="relative group">
                  <input 
                    required
                    type="tel" 
                    placeholder="رقم الهاتف (الخلوي)..." 
                    value={trackPhoneInput}
                    onChange={(e) => setTrackPhoneInput(e.target.value)}
                    className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-4 py-3 text-xs outline-none focus:border-orange-500 focus:bg-white transition-all text-left font-mono font-black"
                  />
                </div>

                <button 
                  type="submit"
                  disabled={isTrackSearchLoading}
                  className="w-full h-11 bg-zinc-950 text-white hover:bg-black font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 shadow active:scale-95 disabled:opacity-50 select-none cursor-pointer"
                >
                  {isTrackSearchLoading ? (
                    <Loader2 size={12} className="animate-spin" />
                  ) : (
                    <span>تتبع الآن 🚴</span>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* PAST ORDERS ARCHIVE DETAIL POPUP MODAL */}
      <AnimatePresence>
        {showHistoryModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center px-4" dir="rtl">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowHistoryModal(false)}
              className="absolute inset-0 bg-neutral-900/60 backdrop-blur-sm cursor-pointer"
            />

            <motion.div 
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.95 }}
              className="bg-white rounded-[2.5rem] p-6 max-w-md w-full max-h-[82vh] overflow-y-auto relative z-10 border border-zinc-200 shadow-2xl flex flex-col"
            >
              <div className="flex justify-between items-center pb-3 border-b border-zinc-100 mb-4 shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
                    📜
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-zinc-900">سجل الطلبات السابقة</h3>
                    <span className="text-[10px] font-bold text-zinc-400">إجمالي الطلبات المرسلة من جهازك الحالي</span>
                  </div>
                </div>

                <button 
                  onClick={() => setShowHistoryModal(false)}
                  className="p-1.5 bg-zinc-100 hover:bg-zinc-200 rounded-lg text-zinc-650 transition-all"
                >
                  <X size={14} strokeWidth={2.5} />
                </button>
              </div>

              {/* Scrollable list of past orders */}
              <div className="flex-1 overflow-y-auto space-y-3 shrink-0">
                {previousOrders.map((order) => {
                  const itemsCount = (order.items || []).reduce((acc, i) => acc + (i.quantity || 1), 0);
                  const isCurrent = order.id === activeTrackingId;
                  return (
                    <div 
                      key={order.id}
                      className={`bg-zinc-50 border rounded-2xl p-4 flex flex-col justify-between gap-3 text-right ${
                        isCurrent ? 'border-orange-500/50 bg-orange-50/10' : 'border-zinc-200/60'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-3">
                        <div>
                          <span className="text-[9px] font-extrabold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md">
                            كود: #{order.secretCode || "----"}
                          </span>
                          <span className="text-[9px] font-semibold text-zinc-400 block mt-1.5">
                            {(() => {
                              const t = order.timestamp;
                              if (!t) return "الآن";
                              const d = typeof t === 'number' ? new Date(t) : (t.seconds ? new Date(t.seconds * 1000) : new Date());
                              return d.toLocaleDateString('ar-IQ', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                            })()}
                          </span>
                        </div>

                        {/* Status tag */}
                        <div className="text-left select-none">
                          <span className={`text-[9px] font-black px-2.5 py-1 rounded-full ${
                            order.status === 'delivered' 
                              ? 'bg-emerald-50 text-emerald-600' 
                              : (order.status === 'on_way' 
                                  ? 'bg-blue-50 text-blue-600 animate-pulse' 
                                  : 'bg-orange-50 text-orange-600 animate-pulse')
                          }`}>
                            {order.status === 'delivered' ? 'تم الاستلام' : (order.status === 'on_way' ? 'في الطريق' : 'قيد التحضير')}
                          </span>
                        </div>
                      </div>

                      {/* Item list briefly */}
                      <div className="border-t border-zinc-100 pt-2.5">
                        <div className="text-[10px] text-zinc-500 font-bold leading-normal">
                          {order.items?.map((it, idx) => (
                            <span key={idx}>
                              {it.name} ({it.quantity})
                              {idx < (order.items.length - 1) ? " • " : ""}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="border-t border-zinc-100 pt-2.5 flex justify-between items-center gap-4">
                        <span className="text-xs font-mono font-black text-zinc-700">
                          {order.total.toLocaleString()} د.ع
                        </span>

                        <button 
                          onClick={() => {
                            setActiveTrackingId(order.id);
                            safeLocalStorage.setItem('last_order_id', order.id);
                            setShowHistoryModal(false);
                          }}
                          className="px-3 py-1.5 bg-zinc-950 text-white hover:bg-black rounded-xl text-[10px] font-black flex items-center gap-1 transition-all shadow active:scale-95"
                        >
                          <span>تتبع حالة الوجبة 🚴</span>
                          <ChevronLeft size={10} strokeWidth={3} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
