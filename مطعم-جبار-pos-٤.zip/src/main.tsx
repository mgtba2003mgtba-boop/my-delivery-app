import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register PWA service worker with auto-update and immediate refresh logic
const updateSW = registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('New content available, refreshing...');
    updateSW(true); // Force reload
  },
  onOfflineReady() {
    console.log('App is ready for offline use.');
  },
});

// Check for updates every 10 minutes
setInterval(() => {
  updateSW();
}, 600 * 1000);

createRoot(document.getElementById('root')!).render(
    <BrowserRouter>
      <App />
    </BrowserRouter>
);
