import https from 'https';

const urls = [
  'https://github.com/feeei/webview-test/releases/download/v1.0/webview-test.apk',
  'https://github.com/feeei/webview-test/releases/download/v1.1/webview-test.apk',
  'https://github.com/feeei/webview-test/releases/download/v1.0.0/webview-test.apk'
];

function testUrl(url) {
  https.get(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
  }, (res) => {
    console.log(`URL: ${url} -> Status: ${res.statusCode}`);
    if (res.statusCode === 302 || res.statusCode === 301) {
      console.log(`   -> Redirects to: ${res.headers.location}`);
    }
  }).on('error', (err) => {
    console.log(`URL: ${url} -> Error: ${err.message}`);
  });
}

console.log('Testing feeei webview-test URLs...');
urls.forEach(testUrl);
