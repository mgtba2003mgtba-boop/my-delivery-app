import https from 'https';

const packageVersions = [
  'de.baumann.browser_158.apk',
  'de.baumann.browser_159.apk',
  'de.baumann.browser_160.apk',
  'de.baumann.browser_151.apk',
  'de.baumann.browser_152.apk',
  'de.baumann.browser_153.apk',
  'acr.browser.lightning_125.apk',
  'acr.browser.lightning_126.apk',
  'acr.browser.lightning_124.apk',
  'io.github.muntashirakon.AppManager_410.apk',
  'org.mozilla.fennec_fdroid_125.apk',
  'org.no_ip.aspro.pweb_35.apk',
  'org.no_ip.aspro.pweb_34.apk',
  'org.no_ip.aspro.pweb_33.apk',
  'org.no_ip.aspro.pweb_32.apk',
  'org.no_ip.aspro.pweb_31.apk',
  'org.no_ip.aspro.pweb_30.apk',
  'org.no_ip.aspro.pweb_29.apk'
];

function testFdroid(name) {
  const url = `https://f-droid.org/repo/${name}`;
  https.get(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  }, (res) => {
    if (res.statusCode === 200 || res.statusCode === 302 || res.statusCode === 301) {
      console.log(`✅ FOUND: ${name} -> Status: ${res.statusCode}`);
    } else {
      // quiet for failing ones
    }
  }).on('error', (err) => {
    // quiet
  });
}

console.log('Testing F-Droid packages...');
packageVersions.forEach(testFdroid);
