import fs from 'fs';
import path from 'path';

const filePath = path.join(process.cwd(), 'public', 'jabar_drivers.apk');
if (!fs.existsSync(filePath)) {
  console.log('File does not exist!');
} else {
  const stats = fs.statSync(filePath);
  console.log(`File size: ${stats.size} bytes`);
  
  const fd = fs.openSync(filePath, 'r');
  const buffer = Buffer.alloc(10);
  fs.readSync(fd, buffer, 0, 10, 0);
  fs.closeSync(fd);
  
  console.log('First 10 bytes:', buffer.toString('hex'), buffer.toString());
}
